import fs from "fs"
import path from "path"
import { v4 as uuidv4 } from "uuid"

// Define user type
export interface User {
  id: string
  phoneNumber: string
  fullName: string
  password: string
  createdAt: string
  isWhatsappVerified: boolean
}

// Ensure directories exist
const DATA_DIR = path.join(process.cwd(), "data")
const USERS_FILE = path.join(DATA_DIR, "users.json")
const CONTACTS_FILE = path.join(DATA_DIR, "nomor_wa.txt")

// Create directories if they don't exist
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true })
}

// Initialize files if they don't exist
if (!fs.existsSync(USERS_FILE)) {
  fs.writeFileSync(USERS_FILE, JSON.stringify([]))
}

if (!fs.existsSync(CONTACTS_FILE)) {
  fs.writeFileSync(CONTACTS_FILE, "")
}

// Cache for verified numbers to prevent spam checks
const verifiedNumbersCache = new Map<string, { isVerified: boolean; timestamp: number }>()
// Cache expiration time: 1 hour (in milliseconds)
const CACHE_EXPIRATION = 60 * 60 * 1000

// Get all users
export const getUsers = (): User[] => {
  try {
    const data = fs.readFileSync(USERS_FILE, "utf8")
    return JSON.parse(data)
  } catch (error) {
    console.error("Error reading users file:", error)
    return []
  }
}

// Get user by phone number
export const getUserByPhone = (phoneNumber: string): User | null => {
  const users = getUsers()
  return users.find((user) => user.phoneNumber === phoneNumber) || null
}

// Create a new user
export const createUser = async (userData: Omit<User, "id" | "createdAt" | "isWhatsappVerified">): Promise<User> => {
  const users = getUsers()

  // Check if user already exists
  if (users.some((user) => user.phoneNumber === userData.phoneNumber)) {
    throw new Error("User with this phone number already exists")
  }

  // Verify WhatsApp number
  const isWhatsappVerified = await verifyWhatsAppNumber(userData.phoneNumber)

  // Create new user
  const newUser: User = {
    id: uuidv4(),
    ...userData,
    createdAt: new Date().toISOString(),
    isWhatsappVerified,
  }

  // Add user to database
  users.push(newUser)
  fs.writeFileSync(USERS_FILE, JSON.stringify(users, null, 2))

  // If WhatsApp verified, add to contacts file
  if (isWhatsappVerified) {
    const formattedNumber = userData.phoneNumber.startsWith("62")
      ? userData.phoneNumber
      : `62${userData.phoneNumber.replace(/^0+/, "")}`

    fs.appendFileSync(CONTACTS_FILE, `https://wa.me/${formattedNumber}\n`)
  }

  return newUser
}

// Verify user credentials
export const verifyCredentials = (phoneNumber: string, password: string): User | null => {
  const user = getUserByPhone(phoneNumber)
  if (user && user.password === password) {
    return user
  }
  return null
}

// Update the verifyWhatsAppNumber function to use caching and handle inactive numbers correctly
export const verifyWhatsAppNumber = async (phoneNumber: string): Promise<boolean> => {
  try {
    // Format the phone number to ensure it starts with 62
    let formattedNumber = phoneNumber
    if (phoneNumber.startsWith("0")) {
      formattedNumber = `62${phoneNumber.substring(1)}`
    } else if (!phoneNumber.startsWith("62")) {
      formattedNumber = `62${phoneNumber}`
    }

    // Check cache first to prevent spam checks
    const cachedResult = verifiedNumbersCache.get(formattedNumber)
    if (cachedResult && Date.now() - cachedResult.timestamp < CACHE_EXPIRATION) {
      console.log(
        `Using cached verification result for ${formattedNumber}: ${cachedResult.isVerified ? "active" : "inactive"}`,
      )
      return cachedResult.isVerified
    }

    try {
      // Call the WhatsApp verification API at the correct endpoint
      console.log(`Verifying WhatsApp number: ${formattedNumber}`)
      const response = await fetch(`http://localhost:8000/check?nomor=${formattedNumber}`)

      // Check if the response is OK before parsing JSON
      if (!response.ok) {
        console.warn(`WhatsApp verification server returned ${response.status}: ${response.statusText}`)
        // Fallback to basic validation in case of API error
        const isValidIndonesianNumber = /^62[8][1-9][0-9]{6,10}$/.test(formattedNumber)
        console.log(`Falling back to basic validation: ${isValidIndonesianNumber ? "valid" : "invalid"} number format`)

        // Cache the result
        verifiedNumbersCache.set(formattedNumber, {
          isVerified: isValidIndonesianNumber,
          timestamp: Date.now(),
        })

        return isValidIndonesianNumber
      }

      const data = await response.json()
      console.log(`WhatsApp verification response:`, data)

      // Check if the number is active and cache the result
      const isActive = data.wa === "active"
      verifiedNumbersCache.set(formattedNumber, {
        isVerified: isActive,
        timestamp: Date.now(),
      })

      return isActive
    } catch (apiError) {
      console.error("Error calling WhatsApp verification API:", apiError)

      // Fallback to basic validation if API is not available
      const isValidIndonesianNumber = /^62[8][1-9][0-9]{6,10}$/.test(formattedNumber)
      console.log(
        `API unavailable, using basic validation: ${isValidIndonesianNumber ? "valid" : "invalid"} number format`,
      )

      // Cache the result
      verifiedNumbersCache.set(formattedNumber, {
        isVerified: isValidIndonesianNumber,
        timestamp: Date.now(),
      })

      return isValidIndonesianNumber
    }
  } catch (error) {
    console.error("Error in WhatsApp verification process:", error)
    return false
  }
}

// Add a function to check if a number is already in the cache
export const isNumberVerified = (phoneNumber: string): boolean | null => {
  // Format the phone number to ensure it starts with 62
  let formattedNumber = phoneNumber
  if (phoneNumber.startsWith("0")) {
    formattedNumber = `62${phoneNumber.substring(1)}`
  } else if (!phoneNumber.startsWith("62")) {
    formattedNumber = `62${phoneNumber}`
  }

  const cachedResult = verifiedNumbersCache.get(formattedNumber)
  if (cachedResult && Date.now() - cachedResult.timestamp < CACHE_EXPIRATION) {
    return cachedResult.isVerified
  }

  return null // Not in cache or expired
}
