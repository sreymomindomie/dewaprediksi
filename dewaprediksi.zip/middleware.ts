import { NextResponse } from "next/server"
import type { NextRequest } from "next/server"

export function middleware(request: NextRequest) {
  // Get the pathname
  const path = request.nextUrl.pathname

  // Define public paths that don't require authentication
  const isPublicPath =
    path === "/api/auth/login" ||
    path === "/api/auth/register" ||
    path === "/api/auth/verify-whatsapp" ||
    path === "/api/prediction" // Add this line to make the prediction API public

  // Get the token from the cookies
  const token = request.cookies.get("token")?.value

  // Redirect logic for API routes
  if (path.startsWith("/api/") && !isPublicPath && !token) {
    return NextResponse.json({ error: "Authentication required" }, { status: 401 })
  }

  return NextResponse.next()
}

// Specify the paths that should trigger this middleware
export const config = {
  matcher: ["/api/:path*"],
}
