import type { MetadataRoute } from "next"

export default function manifest(): MetadataRoute.Manifest {
  return {
    name: "Dewa Prediksi - Ramalan Togel Akurat",
    short_name: "Dewa Prediksi",
    description: "Dapatkan prediksi togel terjitu dari Dewa Prediksi untuk semua pasaran.",
    start_url: "/",
    display: "standalone",
    background_color: "#312e81",
    theme_color: "#312e81",
    icons: [
      {
        src: "/favicon.ico",
        sizes: "any",
        type: "image/x-icon",
      },
      {
        src: "/icon-192.png",
        sizes: "192x192",
        type: "image/png",
      },
      {
        src: "/icon-512.png",
        sizes: "512x512",
        type: "image/png",
      },
      {
        src: "/icon-maskable.png",
        sizes: "512x512",
        type: "image/png",
        purpose: "maskable",
      },
    ],
  }
}
