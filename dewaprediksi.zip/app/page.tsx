import { PredictionForm } from "@/components/prediction-form"
import { MarketBanner } from "@/components/market-banner"
import { MainTabs } from "@/components/main-tabs"
import { HeroSection } from "@/components/hero-section"
import { FloatingActionButton } from "@/components/floating-action-button"
import { ChatDialog } from "@/components/chat-dialog"
import { StructuredData } from "@/components/structured-data"
import ErrorBoundary from "@/components/error-boundary"

export default function Home() {
  return (
    <main className="min-h-screen bg-gradient-to-b from-purple-950 to-indigo-950 text-white">
      <StructuredData />
      <HeroSection />
      <MarketBanner />
      <div className="container mx-auto px-4 sm:px-6 py-8">
        <ErrorBoundary>
          <PredictionForm />
        </ErrorBoundary>
        <div className="mt-8">
          <MainTabs />
        </div>
      </div>
      <FloatingActionButton />
      <ChatDialog />
    </main>
  )
}
