import { type NextRequest, NextResponse } from "next/server"
import { verifyWhatsAppNumber, isNumberVerified } from "@/lib/user-service"

export async function GET(request: NextRequest) {
  try {
    const phoneNumber = request.nextUrl.searchParams.get("phoneNumber")

    if (!phoneNumber) {
      return NextResponse.json({ error: "Phone number is required" }, { status: 400 })
    }

    console.log(`API route: Verifying WhatsApp number ${phoneNumber}`)

    // Format phone number to ensure it starts with 62
    let formattedNumber = phoneNumber
    if (phoneNumber.startsWith("0")) {
      formattedNumber = `62${phoneNumber.substring(1)}`
    } else if (!phoneNumber.startsWith("62")) {
      formattedNumber = `62${phoneNumber}`
    }

    // Check if the number is already in the cache
    const cachedVerification = isNumberVerified(formattedNumber)

    let isVerified: boolean
    let message: string

    if (cachedVerification !== null) {
      // Use cached result
      isVerified = cachedVerification
      message = isVerified
        ? "WhatsApp number verified successfully (cached)"
        : "WhatsApp number could not be verified (cached)"

      console.log(
        `API route: Using cached verification result for ${formattedNumber}: ${isVerified ? "verified" : "not verified"}`,
      )
    } else {
      // Perform new verification
      isVerified = await verifyWhatsAppNumber(formattedNumber)
      message = isVerified ? "WhatsApp number verified successfully" : "WhatsApp number could not be verified"

      console.log(
        `API route: New verification result for ${formattedNumber}: ${isVerified ? "verified" : "not verified"}`,
      )
    }

    return NextResponse.json({
      isVerified,
      message,
    })
  } catch (error) {
    console.error("WhatsApp verification error in API route:", error)
    return NextResponse.json({ error: "WhatsApp verification failed", isVerified: false }, { status: 500 })
  }
}
