import { type NextRequest, NextResponse } from "next/server"
import { createUser, getUserByPhone } from "@/lib/user-service"

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { phoneNumber, fullName, password } = body

    // Validate input
    if (!phoneNumber || !fullName || !password) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 })
    }

    // Check if user already exists
    const existingUser = getUserByPhone(phoneNumber)
    if (existingUser) {
      return NextResponse.json({ error: "User with this phone number already exists" }, { status: 409 })
    }

    // Create user
    const user = await createUser({ phoneNumber, fullName, password })

    // Return user without password
    const { password: _, ...userWithoutPassword } = user

    return NextResponse.json({
      user: userWithoutPassword,
      message: user.isWhatsappVerified
        ? "Registration successful! Your WhatsApp number has been verified."
        : "Registration successful, but your WhatsApp number could not be verified. Some features may be limited.",
    })
  } catch (error) {
    console.error("Registration error:", error)
    return NextResponse.json({ error: "Registration failed" }, { status: 500 })
  }
}
