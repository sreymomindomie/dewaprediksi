import type React from "react"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import "./globals.css"
import { ThemeProvider } from "@/components/theme-provider"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "DEWA PREDIKSI | PREDIKSI JITU TOGEL ONLINE PALING AKURAT HARI INI",
  description:
    "Dewa Prediksi merupakan Prediksi jitu togel online paling akurat hari ini untuk semua pasaran togel seperti HK, SGP, SDY dan Prediksi terlengkap untuk 4D, 3D, 2D, BBFS, Colok bebas, colok macau, syair togel dan shio togel, dengan berbagai update setiap hari nya.",
  keywords:
    "dewa prediksi, prediksi togel, angka jitu, ramalan togel, bocoran togel, togel online, prediksi hongkong, prediksi singapore, prediksi sydney, angka main",
  authors: [{ name: "Dewa Prediksi" }],
  creator: "Dewa Prediksi",
  publisher: "Dewa Prediksi",
  formatDetection: {
    email: false,
    address: false,
    telephone: false,
  },
  metadataBase: new URL("https://dewaprediksi.com"),
  alternates: {
    canonical: "/",
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      "max-image-preview": "large",
      "max-snippet": -1,
    },
  },
  openGraph: {
    type: "website",
    locale: "id_ID",
    url: "https://dewaprediksi.com",
    title: "DEWA PREDIKSI | PREDIKSI JITU TOGEL ONLINE PALING AKURAT HARI INI",
    description:
      "Dewa Prediksi merupakan Prediksi jitu togel online paling akurat hari ini untuk semua pasaran togel seperti HK, SGP, SDY dan Prediksi terlengkap untuk 4D, 3D, 2D, BBFS, Colok bebas, colok macau, syair togel dan shio togel, dengan berbagai update setiap hari nya.",
    siteName: "Dewa Prediksi",
    images: [
      {
        url: "/og-image.png",
        width: 1200,
        height: 630,
        alt: "Dewa Prediksi - Ramalan Togel Akurat",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: "DEWA PREDIKSI | PREDIKSI JITU TOGEL ONLINE PALING AKURAT HARI INI",
    description:
      "Dewa Prediksi merupakan Prediksi jitu togel online paling akurat hari ini untuk semua pasaran togel seperti HK, SGP, SDY dan Prediksi terlengkap untuk 4D, 3D, 2D, BBFS, Colok bebas, colok macau, syair togel dan shio togel, dengan berbagai update setiap hari nya.",
    images: ["/twitter-image.png"],
    creator: "@dewaprediksi",
  },
    generator: 'luminaryAI-eclipse'
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="id" suppressHydrationWarning>
      <head>
        {/* Tambahan meta tags untuk SEO */}
        <link rel="canonical" href="https://dewaprediksi.com" />
        <meta name="google-site-verification" content="your-verification-code" />
        <meta name="facebook-domain-verification" content="your-verification-code" />
        <meta name="msvalidate.01" content="your-verification-code" />

        {/* Structured Data / JSON-LD untuk Rich Snippets */}
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify({
              "@context": "https://schema.org",
              "@type": "WebSite",
              name: "Dewa Prediksi",
              url: "https://dewaprediksi.com",
              potentialAction: {
                "@type": "SearchAction",
                target: "https://dewaprediksi.com/search?q={search_term_string}",
                "query-input": "required name=search_term_string",
              },
            }),
          }}
        />

        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify({
              "@context": "https://schema.org",
              "@type": "Organization",
              name: "Dewa Prediksi",
              url: "https://dewaprediksi.com",
              logo: "https://dewaprediksi.com/logo.png",
              sameAs: [
                "https://facebook.com/dewaprediksi",
                "https://twitter.com/dewaprediksi",
                "https://instagram.com/dewaprediksi",
              ],
            }),
          }}
        />
      </head>
      <body className={inter.className}>
        <ThemeProvider attribute="class" defaultTheme="dark" enableSystem disableTransitionOnChange>
          {children}
        </ThemeProvider>
      </body>
    </html>
  )
}
