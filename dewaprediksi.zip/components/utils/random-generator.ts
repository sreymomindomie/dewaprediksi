// Fungsi untuk menghasilkan tanggal acak dalam rentang tertentu
export function generateRandomDate(startDate: Date, endDate: Date): Date {
  const startTimestamp = startDate.getTime()
  const endTimestamp = endDate.getTime()
  const randomTimestamp = startTimestamp + Math.random() * (endTimestamp - startTimestamp)
  return new Date(randomTimestamp)
}

// Fungsi untuk menghasilkan angka togel 4D acak
export function generateRandom4D(): string {
  return Math.floor(1000 + Math.random() * 9000).toString()
}

// Fungsi untuk menghasilkan array angka togel 4D acak
export function generateMultipleRandom4D(count: number): string[] {
  const results: string[] = []
  for (let i = 0; i < count; i++) {
    results.push(generateRandom4D())
  }
  return results
}

// Fungsi untuk menghasilkan waktu acak dalam format jam:menit
export function generateRandomTime(): string {
  const hours = Math.floor(Math.random() * 24)
    .toString()
    .padStart(2, "0")
  const minutes = Math.floor(Math.random() * 60)
    .toString()
    .padStart(2, "0")
  return `${hours}:${minutes}`
}

// Fungsi untuk menghasilkan persentase acak dalam rentang tertentu
export function generateRandomPercentage(min: number, max: number): number {
  return Math.floor(min + Math.random() * (max - min))
}

// Fungsi untuk menghasilkan status RTP acak
export function generateRandomRTPStatus(): "bocor" | "normal" | "hot" {
  const statuses: Array<"bocor" | "normal" | "hot"> = ["bocor", "normal", "hot"]
  const randomIndex = Math.floor(Math.random() * statuses.length)
  return statuses[randomIndex]
}

// Fungsi untuk menghasilkan array angka acak dalam rentang tertentu
export function generateRandomNumbersInRange(min: number, max: number, count: number): number[] {
  const numbers: number[] = []
  for (let i = 0; i < count; i++) {
    numbers.push(Math.floor(min + Math.random() * (max - min + 1)))
  }
  return numbers
}

// Fungsi untuk menghasilkan string waktu yang telah berlalu secara acak
export function generateRandomElapsedTime(): string {
  const options = [
    "Baru saja",
    "1 menit yang lalu",
    "5 menit yang lalu",
    "10 menit yang lalu",
    "15 menit yang lalu",
    "30 menit yang lalu",
    "1 jam yang lalu",
    "2 jam yang lalu",
    "3 jam yang lalu",
  ]

  return options[Math.floor(Math.random() * options.length)]
}
