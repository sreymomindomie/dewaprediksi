"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { motion, AnimatePresence } from "framer-motion"
import { Trophy, Sparkles } from "lucide-react"

type Winner = {
  name: string
  phoneNumber: string
  amount: string
  market: string
  time: string
  predictionType: string
  predictionInput: string
}

export function WinnersList() {
  const [winners, setWinners] = useState<Winner[]>([])

  // Generate pemenang dari prediksi AI
  useEffect(() => {
    const names = [
      "Budi S.",
      "Siti R.",
      "Ahmad D.",
      "Dewi L.",
      "Joko W.",
      "Rina P.",
      "Agus H.",
      "Lina K.",
      "Dedi S.",
      "Maya T.",
    ]

    const markets = ["Hongkong", "Singapore", "Sydney", "Macau", "Taiwan"]

    const predictionTypes = ["Mimpi", "Kejadian Sehari-hari", "Tanggal Lahir", "Plat Nomor", "Nama"]

    const predictionInputs = [
      "Mimpi dikejar ular besar",
      "Bertemu kucing hitam di jalan",
      "Tanggal lahir anak saya 12-05-2020",
      "Plat nomor mobil baru B 1234 CD",
      "Nama anak yang baru lahir",
      "Melihat angka 2795 berulang kali",
      "Mimpi hujan deras dan banjir",
      "Bertemu dengan teman lama",
      "Melihat pelangi kembar",
    ]

    const generatePhoneNumber = () => {
      const prefix = "08"
      const number = Math.floor(Math.random() * 1000000000)
        .toString()
        .padStart(9, "0")
      return `${prefix}${number.substring(0, 3)}****${number.substring(7)}`
    }

    const generateAmount = () => {
      const amounts = [
        "Rp 5.000.000",
        "Rp 10.000.000",
        "Rp 25.000.000",
        "Rp 50.000.000",
        "Rp 100.000.000",
        "Rp 250.000.000",
      ]
      return amounts[Math.floor(Math.random() * amounts.length)]
    }

    const generateTime = () => {
      const hours = Math.floor(Math.random() * 24)
        .toString()
        .padStart(2, "0")
      const minutes = Math.floor(Math.random() * 60)
        .toString()
        .padStart(2, "0")
      return `${hours}:${minutes}`
    }

    const initialWinners: Winner[] = []
    for (let i = 0; i < 5; i++) {
      initialWinners.push({
        name: names[Math.floor(Math.random() * names.length)],
        phoneNumber: generatePhoneNumber(),
        amount: generateAmount(),
        market: markets[Math.floor(Math.random() * markets.length)],
        time: generateTime(),
        predictionType: predictionTypes[Math.floor(Math.random() * predictionTypes.length)],
        predictionInput: predictionInputs[Math.floor(Math.random() * predictionInputs.length)],
      })
    }

    setWinners(initialWinners)

    // Add new winner every 10 seconds
    const interval = setInterval(() => {
      const newWinner = {
        name: names[Math.floor(Math.random() * names.length)],
        phoneNumber: generatePhoneNumber(),
        amount: generateAmount(),
        market: markets[Math.floor(Math.random() * markets.length)],
        time: generateTime(),
        predictionType: predictionTypes[Math.floor(Math.random() * predictionTypes.length)],
        predictionInput: predictionInputs[Math.floor(Math.random() * predictionInputs.length)],
      }

      setWinners((prev) => [newWinner, ...prev.slice(0, 4)])
    }, 10000)

    return () => clearInterval(interval)
  }, [])

  return (
    <Card className="bg-gradient-to-br from-purple-800/50 via-indigo-800/50 to-purple-800/50 border-purple-500/30 shadow-lg overflow-hidden">
      <CardHeader className="pb-2 bg-gradient-to-r from-purple-800/50 to-indigo-800/50">
        <CardTitle className="text-white text-base sm:text-xl flex items-center">
          <Trophy className="mr-2 h-4 w-4 sm:h-5 sm:w-5 text-yellow-400" />
          Pemenang Prediksi AI
        </CardTitle>
      </CardHeader>
      <CardContent className="p-0">
        <div className="max-h-[250px] sm:max-h-[300px] overflow-hidden">
          <AnimatePresence initial={false}>
            {winners.map((winner, index) => (
              <motion.div
                key={`${winner.name}-${winner.time}-${index}`}
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: "auto" }}
                exit={{ opacity: 0, height: 0 }}
                transition={{ duration: 0.3 }}
                className={`p-3 sm:p-4 border-b border-purple-700/30 ${
                  index % 2 === 0 ? "bg-purple-800/20" : "bg-purple-800/10"
                }`}
              >
                <div className="flex justify-between items-center mb-2">
                  <div>
                    <div className="font-medium text-white text-sm sm:text-base">{winner.name}</div>
                    <div className="text-xs text-purple-300">{winner.phoneNumber}</div>
                  </div>
                  <div className="text-right">
                    <div className="font-bold text-yellow-300 text-sm sm:text-base">{winner.amount}</div>
                    <div className="flex items-center justify-end mt-1">
                      <Badge variant="outline" className="text-xs border-purple-500/30 text-purple-200">
                        {winner.market}
                      </Badge>
                      <span className="text-xs text-purple-400 ml-2">{winner.time}</span>
                    </div>
                  </div>
                </div>
                <div className="mt-2 bg-purple-900/40 p-2 rounded-md">
                  <div className="flex items-center text-xs text-purple-200 mb-1">
                    <Sparkles className="h-3 w-3 mr-1 text-yellow-400" />
                    <span>Prediksi: {winner.predictionType}</span>
                  </div>
                  <div className="text-xs text-white line-clamp-1">{winner.predictionInput}</div>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      </CardContent>
    </Card>
  )
}
