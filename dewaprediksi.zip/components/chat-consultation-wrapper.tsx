"use client"

import { useState, useEffect } from "react"
import dynamic from "next/dynamic"
import { Loader2 } from "lucide-react"

// Dynamically import the ChatConsultation component with no SSR
const ChatConsultationWithNoSSR = dynamic(() => import("./chat-consultation"), {
  ssr: false,
  loading: () => (
    <div className="bg-gradient-to-br from-purple-800/50 via-indigo-800/50 to-purple-800/50 backdrop-blur-md border-purple-500/30 shadow-lg overflow-hidden h-[600px] flex items-center justify-center">
      <Loader2 className="h-8 w-8 animate-spin text-purple-400" />
    </div>
  ),
})

export default function ChatConsultationWrapper() {
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) {
    return (
      <div className="bg-gradient-to-br from-purple-800/50 via-indigo-800/50 to-purple-800/50 backdrop-blur-md border-purple-500/30 shadow-lg overflow-hidden h-[600px] flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-purple-400" />
      </div>
    )
  }

  return <ChatConsultationWithNoSSR />
}
