"use client"

import { useState, useEffect } from "react"
import { Card } from "@/components/ui/card"
import { motion } from "framer-motion"

export function JackpotCounter() {
  const [jackpot, setJackpot] = useState(1000000000)
  const [displayValue, setDisplayValue] = useState("1,000,000,000")

  useEffect(() => {
    // Increment jackpot every second
    const interval = setInterval(() => {
      setJackpot((prev) => {
        const increment = Math.floor(Math.random() * 100000) + 10000
        return prev + increment
      })
    }, 1000)

    return () => clearInterval(interval)
  }, [])

  useEffect(() => {
    // Format jackpot for display
    setDisplayValue(jackpot.toLocaleString("id-ID"))
  }, [jackpot])

  return (
    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8 }}>
      <Card className="bg-gradient-to-r from-purple-800/80 via-indigo-800/80 to-purple-800/80 border-purple-500/30 shadow-xl backdrop-blur-md overflow-hidden">
        <div className="relative p-4 sm:p-6 md:p-8">
          {/* Background Pattern */}
          <div className="absolute inset-0 opacity-10">
            <svg width="100%" height="100%" xmlns="http://www.w3.org/2000/svg">
              <defs>
                <pattern id="smallGrid" width="10" height="10" patternUnits="userSpaceOnUse">
                  <path d="M 10 0 L 0 0 0 10" fill="none" stroke="white" strokeWidth="0.5" />
                </pattern>
                <pattern id="grid" width="100" height="100" patternUnits="userSpaceOnUse">
                  <rect width="100" height="100" fill="url(#smallGrid)" />
                  <path d="M 100 0 L 0 0 0 100" fill="none" stroke="white" strokeWidth="1" />
                </pattern>
              </defs>
              <rect width="100%" height="100%" fill="url(#grid)" />
            </svg>
          </div>

          <div className="relative z-10">
            <div className="flex flex-col md:flex-row justify-between items-center">
              <div className="mb-4 md:mb-0 text-center md:text-left">
                <h2 className="text-lg sm:text-xl md:text-2xl font-bold text-white">Jackpot Dewa Prediksi Hari Ini</h2>
                <p className="text-sm sm:text-base text-purple-200">Terus bertambah setiap detik!</p>
              </div>

              <div className="flex flex-col items-center">
                <div className="bg-black/30 rounded-lg p-2 sm:p-3 backdrop-blur-sm border border-purple-500/30 shadow-inner">
                  <div className="text-xl sm:text-2xl md:text-4xl font-bold text-yellow-300 font-mono tracking-wider">
                    Rp {displayValue}
                  </div>
                </div>
                <div className="mt-2 text-xs sm:text-sm text-purple-200">Diperbarui secara real-time</div>
              </div>
            </div>
          </div>

          {/* Animated Sparkles */}
          <Sparkles />
        </div>
      </Card>
    </motion.div>
  )
}

function Sparkles() {
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) return null

  return (
    <div className="absolute inset-0 pointer-events-none">
      {[...Array(10)].map((_, i) => (
        <Sparkle key={i} />
      ))}
    </div>
  )
}

function Sparkle() {
  const [sparkleProps, setSparkleProps] = useState({
    size: 0,
    left: "0%",
    top: "0%",
    animationDuration: 0,
    delay: 0,
    visible: false,
  })

  // Only run this effect on the client side
  useEffect(() => {
    // Generate consistent values on client side
    const size = Math.floor(Math.random() * 6) + 2
    const left = `${Math.random() * 100}%`
    const top = `${Math.random() * 100}%`
    const animationDuration = Math.floor(Math.random() * 2) + 1
    const delay = Math.random() * 5

    setSparkleProps({
      size,
      left,
      top,
      animationDuration,
      delay,
      visible: true,
    })
  }, [])

  // Don't render anything during SSR or before client-side values are set
  if (!sparkleProps.visible) return null

  return (
    <motion.div
      className="absolute bg-yellow-300 rounded-full"
      style={{
        width: sparkleProps.size,
        height: sparkleProps.size,
        left: sparkleProps.left,
        top: sparkleProps.top,
      }}
      animate={{
        scale: [0, 1, 0],
        opacity: [0, 1, 0],
      }}
      transition={{
        duration: sparkleProps.animationDuration,
        repeat: Number.POSITIVE_INFINITY,
        delay: sparkleProps.delay,
        ease: "easeInOut",
      }}
    />
  )
}
