"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Avatar } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Loader2, Send, Sparkles, User, RefreshCw, AlertCircle, Zap } from "lucide-react"
import { motion, AnimatePresence } from "framer-motion"
import axios from "axios"

interface Message {
  id: string
  role: "user" | "assistant"
  content: string
  timestamp: Date
  isLoading?: boolean
  imageUrl?: string
}

// Predefined questions that users can click on
const predefinedQuestions = [
  "Apa angka togel untuk hari ini?",
  "Tafsirkan mimpi saya tentang air",
  "Kapan waktu terbaik untuk memasang togel?",
  "Angka keberuntungan untuk zodiak saya",
]

export function ChatConsultation() {
  // Use client-side only initial state
  const [initialMessages] = useState<Message[]>([
    {
      id: "welcome",
      role: "assistant",
      content:
        "Selamat datang di Konsultasi Dewa Prediksi. Anda dapat bertanya tentang:\n\n• Ramalan angka togel untuk hari ini\n• Tafsir mimpi dan artinya\n• Angka keberuntungan berdasarkan kejadian\n• Prediksi berdasarkan tanggal atau peristiwa\n\nSilakan ketik pertanyaan Anda untuk mendapatkan prediksi.",
      timestamp: new Date(),
    },
  ])

  const [messages, setMessages] = useState<Message[]>(initialMessages)
  const [input, setInput] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const [showPredefinedQuestions, setShowPredefinedQuestions] = useState(true)
  const [sessionId, setSessionId] = useState<string>("temp_session_id")
  const [retryCount, setRetryCount] = useState(0)
  const [isOnline, setIsOnline] = useState(true)
  const [isMounted, setIsMounted] = useState(false)

  // Set mounted state to true after component mounts
  useEffect(() => {
    setIsMounted(true)
  }, [])

  // Add useEffect to monitor online status
  useEffect(() => {
    const handleOnline = () => setIsOnline(true)
    const handleOffline = () => setIsOnline(false)

    window.addEventListener("online", handleOnline)
    window.addEventListener("offline", handleOffline)

    // Set initial status
    setIsOnline(navigator.onLine)

    return () => {
      window.removeEventListener("online", handleOnline)
      window.removeEventListener("offline", handleOffline)
    }
  }, [])

  // Initialize session ID on client-side only
  useEffect(() => {
    // Use existing session ID from localStorage or create a new one
    const existingId = localStorage.getItem("dewaPrediksiChatId")
    if (existingId) {
      setSessionId(existingId)
    } else {
      // Use a phone number format for the session ID (e.g., 628123456789)
      const newId = `628${Math.floor(Math.random() * 10000000000)}`
      localStorage.setItem("dewaPrediksiChatId", newId)
      setSessionId(newId)
    }

    // Load chat history from localStorage
    const savedMessages = localStorage.getItem("dewaPrediksiChatHistory")
    if (savedMessages) {
      try {
        const parsedMessages = JSON.parse(savedMessages)
        // Convert string timestamps back to Date objects
        const messagesWithDates = parsedMessages.map((msg: any) => ({
          ...msg,
          timestamp: new Date(msg.timestamp),
        }))
        setMessages(messagesWithDates)
      } catch (e) {
        console.error("Error loading chat history:", e)
      }
    }
  }, [])

  // Save messages to localStorage whenever they change
  useEffect(() => {
    if (messages.length > 1 && isMounted) {
      // Don't save if it's just the welcome message or if not mounted
      localStorage.setItem("dewaPrediksiChatHistory", JSON.stringify(messages))
    }
  }, [messages, isMounted])

  // Scroll to bottom of chat when messages change
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }, [messages])

  // Handle predefined question selection
  const handlePredefinedQuestion = (question: string) => {
    setInput(question)
    setShowPredefinedQuestions(false)
    // Optional: automatically send the question
    setTimeout(() => sendMessage(), 500)
  }

  // Update the sendMessage function to use the correct API
  const sendMessage = async () => {
    if (!input.trim()) return

    const messageId = `msg_${Date.now()}`
    const userMessage: Message = {
      id: messageId,
      role: "user",
      content: input,
      timestamp: new Date(),
    }

    // Add user message to chat
    setMessages((prev) => [...prev, userMessage])

    // Hide predefined questions after user sends a message
    setShowPredefinedQuestions(false)

    // Add loading message
    const loadingMessageId = `loading_${Date.now()}`
    setMessages((prev) => [
      ...prev,
      {
        id: loadingMessageId,
        role: "assistant",
        content: "",
        timestamp: new Date(),
        isLoading: true,
      },
    ])

    setIsLoading(true)
    const userInput = input // Save the input before clearing it
    setInput("")

    try {
      console.log("Making API request to prediction endpoint")

      // Create the request data - simplified to match the API requirements
      const requestData = {
        id: sessionId,
        text: userInput,
      }

      const response = await axios.post("/api/prediction", requestData, {
        timeout: 15000,
        headers: {
          "Content-Type": "application/json",
          Accept: "application/json",
        },
      })

      // Remove loading message
      setMessages((prev) => prev.filter((msg) => msg.id !== loadingMessageId))

      console.log("API response received:", response.data)

      // Extract message from response
      if (response.data && response.data.success && response.data.data && response.data.data.message) {
        const responseMessage = response.data.data.message
        const responseImage = response.data.data.image || null

        setMessages((prev) => [
          ...prev,
          {
            id: `resp_${Date.now()}`,
            role: "assistant",
            content: responseMessage,
            timestamp: new Date(),
            imageUrl: responseImage,
          },
        ])
      } else {
        throw new Error("Invalid response format from our API")
      }
    } catch (error: any) {
      console.error("Error with our API endpoint:", error)

      // Remove loading message
      setMessages((prev) => prev.filter((msg) => msg.id !== loadingMessageId))

      // Add fallback response with mystical content based on the user's question
      const userQuestion = userInput.toLowerCase()
      let fallbackResponse = ""

      if (userQuestion.includes("angka") || userQuestion.includes("nomor") || userQuestion.includes("togel")) {
        // Generate random numbers for togel predictions
        const randomNumbers = Array.from({ length: 4 }, () => Math.floor(Math.random() * 10)).join(", ")
        fallbackResponse = `Dewa Prediksi telah menerima pertanyaan Anda tentang angka keberuntungan. Setelah melakukan ritual khusus dan berkomunikasi dengan alam gaib, Dewa melihat angka-angka berikut bersinar terang di masa depan Anda: ${randomNumbers}. Angka-angka ini muncul dari pertemuan energi kosmik yang unik pada hari ini. Gunakan dengan bijak dan penuh keyakinan.`
      } else if (userQuestion.includes("mimpi") || userQuestion.includes("tafsir")) {
        fallbackResponse = `Mimpi yang Anda alami memiliki makna spiritual yang dalam. Dewa Prediksi melihat bahwa mimpi tersebut adalah pesan dari alam bawah sadar yang menunjukkan perubahan energi di sekitar Anda. Angka yang terkait dengan mimpi ini adalah 3, 7, 9, dan 2. Perhatikan juga tanda-tanda di sekitar Anda dalam 3 hari ke depan.`
      } else if (userQuestion.includes("kapan") || userQuestion.includes("hari")) {
        fallbackResponse = `Dewa Prediksi melihat bahwa waktu terbaik untuk Anda adalah pada hari Selasa atau Jumat, ketika energi planet Merkurius dan Venus berada dalam keselarasan sempurna. Pada hari-hari tersebut, angka 4, 8, 1, dan 6 akan membawa keberuntungan khusus bagi Anda.`
      } else {
        fallbackResponse = `Dewa Prediksi telah menerima pesan Anda: "${userInput.substring(0, 50)}...". 
      
Setelah melakukan ritual khusus dan meditasi mendalam, Dewa melihat energi kosmik yang kuat dalam pertanyaan Anda. Meskipun koneksi ke alam gaib sedang terganggu, Dewa dapat memberikan wawasan ini:

Angka keberuntungan Anda hari ini adalah 4, 7, 9, dan 2. Energi planet Jupiter sedang berpihak pada Anda, membawa keberuntungan dalam hal-hal yang tidak terduga.

Silakan ajukan pertanyaan yang lebih spesifik untuk mendapatkan ramalan yang lebih mendalam.`
      }

      setMessages((prev) => [
        ...prev,
        {
          id: `fallback_${Date.now()}`,
          role: "assistant",
          content: fallbackResponse,
          timestamp: new Date(),
        },
      ])
    } finally {
      setIsLoading(false)
    }
  }

  // Add a function to retry sending a message
  const retryMessage = () => {
    if (messages.length > 0) {
      // Find the last user message
      const lastUserMessage = [...messages].reverse().find((msg) => msg.role === "user")

      if (lastUserMessage) {
        // Set the input to the last user message content
        setInput(lastUserMessage.content)

        // Remove the error message
        const errorMessages = messages.filter((msg) => msg.id.startsWith("error_") || msg.id.startsWith("fallback_"))

        if (errorMessages.length > 0) {
          setMessages((prev) => prev.filter((msg) => !errorMessages.some((errMsg) => errMsg.id === msg.id)))
        }

        // Increment retry count
        setRetryCount((prev) => prev + 1)

        // Send the message again
        sendMessage()
      }
    }
  }

  // Clear chat history
  const clearChat = () => {
    // Keep only the welcome message
    setMessages([
      {
        id: "welcome",
        role: "assistant",
        content:
          "Selamat datang di Konsultasi Dewa Prediksi. Anda dapat bertanya tentang:\n\n• Ramalan angka togel untuk hari ini\n• Tafsir mimpi dan artinya\n• Angka keberuntungan berdasarkan kejadian\n• Prediksi berdasarkan tanggal atau peristiwa\n\nSilakan ketik pertanyaan Anda untuk mendapatkan prediksi.",
        timestamp: new Date(),
      },
    ])
    // Clear localStorage
    localStorage.removeItem("dewaPrediksiChatHistory")
    // Show predefined questions again
    setShowPredefinedQuestions(true)
  }

  // Handle Enter key press
  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault()
      sendMessage()
    }
  }

  // Format timestamp
  const formatTime = (date: Date) => {
    return date.toLocaleTimeString("id-ID", {
      hour: "2-digit",
      minute: "2-digit",
    })
  }

  // If not mounted yet, return a simple loading state
  if (!isMounted) {
    return (
      <Card className="bg-gradient-to-br from-purple-800/50 via-indigo-800/50 to-purple-800/50 backdrop-blur-md border-purple-500/30 shadow-lg overflow-hidden h-[500px] sm:h-[600px] flex flex-col">
        <CardHeader className="pb-2 bg-gradient-to-r from-purple-800/50 to-indigo-800/50 relative">
          <div className="absolute inset-0 bg-grid-white/5 opacity-10"></div>
          <div className="relative z-10 flex justify-between items-center">
            <div className="flex items-center gap-2 sm:gap-3">
              <Avatar className="h-8 w-8 sm:h-10 sm:w-10 bg-gradient-to-r from-yellow-600 to-amber-600 p-1">
                <Sparkles className="h-5 w-5 sm:h-6 sm:w-6 text-white" />
              </Avatar>
              <div>
                <CardTitle className="text-sm sm:text-base text-white flex items-center">
                  Konsultasi Dewa Prediksi
                </CardTitle>
                <Badge className="bg-green-600 text-white text-xs">Loading...</Badge>
              </div>
            </div>
          </div>
        </CardHeader>
        <CardContent className="flex-1 flex items-center justify-center">
          <Loader2 className="h-8 w-8 animate-spin text-purple-400" />
        </CardContent>
      </Card>
    )
  }

  return (
    <Card className="bg-gradient-to-br from-purple-800/50 via-indigo-800/50 to-purple-800/50 backdrop-blur-md border-purple-500/30 shadow-lg overflow-hidden h-[500px] sm:h-[600px] flex flex-col">
      <CardHeader className="pb-2 bg-gradient-to-r from-purple-800/50 to-indigo-800/50 relative p-3 sm:p-4">
        <div className="absolute inset-0 bg-grid-white/5 opacity-10"></div>
        <div className="relative z-10 flex justify-between items-center">
          <div className="flex items-center gap-2 sm:gap-3">
            <Avatar className="h-8 w-8 sm:h-10 sm:w-10 bg-gradient-to-r from-yellow-600 to-amber-600 p-1">
              <Sparkles className="h-5 w-5 sm:h-6 sm:w-6 text-white" />
            </Avatar>
            <div>
              <CardTitle className="text-sm sm:text-base text-white flex items-center">
                Konsultasi Dewa Prediksi
              </CardTitle>
              {isOnline ? (
                <Badge className="bg-green-600 text-white text-xs">Online</Badge>
              ) : (
                <Badge variant="outline" className="bg-red-500/20 text-red-300 border-red-500/30 text-xs">
                  <AlertCircle className="h-3 w-3 mr-1" />
                  Offline - Koneksi Terputus
                </Badge>
              )}
            </div>
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={clearChat}
            className="text-white hover:bg-white/10 text-xs sm:text-sm px-2 sm:px-3 h-8 sm:h-9"
          >
            Bersihkan Chat
          </Button>
        </div>
      </CardHeader>

      <CardContent className="flex-1 overflow-y-auto p-3 sm:p-4 space-y-3 sm:space-y-4">
        <AnimatePresence>
          {messages.map((message) => (
            <motion.div
              key={message.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.3 }}
              className={`flex ${message.role === "user" ? "justify-end" : "justify-start"}`}
            >
              <div
                className={`max-w-[85%] sm:max-w-[80%] rounded-lg p-3 sm:p-4 ${
                  message.role === "user"
                    ? "bg-gradient-to-r from-purple-600 to-indigo-600 text-white"
                    : "bg-gradient-to-r from-purple-900/70 to-indigo-900/70 border border-purple-500/30 text-white"
                }`}
              >
                <div className="flex items-center gap-2 mb-1">
                  {message.role === "assistant" ? (
                    <Sparkles className="h-3 w-3 sm:h-4 sm:w-4 text-yellow-400" />
                  ) : (
                    <User className="h-3 w-3 sm:h-4 sm:w-4 text-white" />
                  )}
                  <span className="font-bold text-xs sm:text-sm">
                    {message.role === "assistant" ? "Dewa Prediksi" : "Anda"}
                  </span>
                  <span className="text-xs opacity-70">{formatTime(message.timestamp)}</span>
                </div>

                {message.isLoading ? (
                  <div className="flex items-center gap-2">
                    <Loader2 className="h-3 w-3 sm:h-4 sm:w-4 animate-spin text-yellow-400" />
                    <span className="text-xs sm:text-sm">Dewa Prediksi sedang meramal...</span>
                  </div>
                ) : (
                  <>
                    <div className="whitespace-pre-line text-xs sm:text-sm">{message.content}</div>

                    {message.imageUrl && (
                      <div className="mt-2 rounded-md overflow-hidden border border-purple-500/30">
                        <img
                          src={message.imageUrl || "/placeholder.svg"}
                          alt="Shared image"
                          className="max-w-full h-auto"
                        />
                      </div>
                    )}

                    {(message.id.startsWith("error_") || message.id.startsWith("fallback_")) &&
                      message.role === "assistant" && (
                        <div className="mt-3 flex justify-end">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={retryMessage}
                            className="bg-white/10 border-purple-500/30 text-white hover:bg-white/20 text-xs px-2 py-1 h-auto"
                          >
                            <RefreshCw className="h-3 w-3 mr-1" />
                            Coba Lagi
                          </Button>
                        </div>
                      )}
                  </>
                )}
              </div>
            </motion.div>
          ))}
        </AnimatePresence>

        {/* Predefined questions */}
        {showPredefinedQuestions && messages.length <= 2 && (
          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="mt-4">
            <div className="text-white text-xs sm:text-sm mb-2 opacity-80">Pertanyaan Popular:</div>
            <div className="flex flex-wrap gap-2">
              {predefinedQuestions.map((question, index) => (
                <Button
                  key={index}
                  variant="outline"
                  size="sm"
                  onClick={() => handlePredefinedQuestion(question)}
                  className="bg-white/10 border-purple-500/30 text-white hover:bg-white/20 text-xs h-auto py-1 px-2"
                >
                  <Zap className="h-3 w-3 mr-1 text-yellow-400" />
                  {question}
                </Button>
              ))}
            </div>
          </motion.div>
        )}

        <div ref={messagesEndRef} />
      </CardContent>

      <div className="p-3 sm:p-4 border-t border-purple-500/30 bg-gradient-to-r from-purple-900/50 to-indigo-900/50">
        <div className="flex gap-2">
          <Textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyPress}
            placeholder="Tanyakan pada Dewa Prediksi..."
            className="flex-1 bg-white/10 border-purple-500/30 text-white placeholder:text-white/70 min-h-[40px] sm:min-h-[44px] max-h-[80px] sm:max-h-[120px] text-xs sm:text-sm py-2 px-3"
            disabled={isLoading}
          />

          <Button
            type="button"
            size="icon"
            className="bg-gradient-to-r from-yellow-600 to-amber-600 hover:from-yellow-700 hover:to-amber-700 text-white h-[40px] w-[40px] sm:h-[44px] sm:w-[44px]"
            onClick={sendMessage}
            disabled={isLoading || !input.trim()}
          >
            {isLoading ? (
              <Loader2 className="h-4 w-4 sm:h-5 sm:w-5 animate-spin" />
            ) : (
              <Send className="h-4 w-4 sm:h-5 sm:w-5" />
            )}
            <span className="sr-only">Send</span>
          </Button>
        </div>
      </div>
    </Card>
  )
}

// Default export for dynamic import
export default ChatConsultation
