"use client"

import { useState, useEffect } from "react"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Clock } from "lucide-react"
import { motion } from "framer-motion"
import { generateRandom4D } from "@/components/utils/random-generator"

type Market = {
  name: string
  time: string
  result: string
  status: "open" | "closed" | "live"
}

export function MarketBanner() {
  const [currentTime, setCurrentTime] = useState(new Date())
  const [markets, setMarkets] = useState<Market[]>([])
  const [hoveredMarket, setHoveredMarket] = useState<number | null>(null)

  // Inisialisasi data pasar togel secara acak
  useEffect(() => {
    const marketNames = ["Hongkong", "Singapore", "Sydney", "Macau", "Taiwan", "Cambodia", "China", "Japan"]
    const marketTimes = ["14:00", "17:45", "19:30", "21:00", "23:00"]
    const statuses: Array<"open" | "closed" | "live"> = ["open", "closed", "live"]

    const randomMarkets: Market[] = marketNames.map((name) => {
      return {
        name,
        time: marketTimes[Math.floor(Math.random() * marketTimes.length)],
        result: generateRandom4D(),
        status: statuses[Math.floor(Math.random() * statuses.length)],
      }
    })

    setMarkets(randomMarkets)
  }, [])

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date())
    }, 1000)
    return () => clearInterval(timer)
  }, [])

  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  }

  const item = {
    hidden: { opacity: 0, y: 20 },
    show: { opacity: 1, y: 0 },
  }

  return (
    <div className="container mx-auto px-4">
      <motion.div
        variants={container}
        initial="hidden"
        animate="show"
        className="mb-8 overflow-x-auto scrollbar-thin scrollbar-thumb-purple-600 scrollbar-track-purple-900/30"
      >
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-8 gap-3 sm:gap-4">
          <motion.div variants={item} className="col-span-2 sm:col-span-3 md:col-span-4 lg:col-span-8">
            <Card className="bg-gradient-to-r from-purple-800/50 to-indigo-800/50 backdrop-blur-md border-purple-500/30 p-3 sm:p-4 flex items-center justify-between shadow-lg">
              <div className="flex items-center">
                <Clock className="h-4 w-4 sm:h-5 sm:w-5 text-white mr-2" />
                <span className="text-sm sm:text-base text-white font-medium">
                  {currentTime.toLocaleTimeString("id-ID", { hour: "2-digit", minute: "2-digit" })}
                </span>
              </div>
              <div className="text-xs sm:text-sm text-white">Waktu Server Indonesia (GMT+7)</div>
            </Card>
          </motion.div>

          {markets.map((market, index) => (
            <motion.div
              key={market.name}
              variants={item}
              onMouseEnter={() => setHoveredMarket(index)}
              onMouseLeave={() => setHoveredMarket(null)}
            >
              <Card
                className={`backdrop-blur-md border-purple-500/30 p-3 sm:p-4 flex flex-col items-center shadow-lg transition-all duration-300 h-full ${
                  hoveredMarket === index
                    ? "bg-gradient-to-b from-purple-700/70 to-indigo-800/70 scale-105 -translate-y-1"
                    : "bg-gradient-to-b from-purple-800/50 to-indigo-900/50"
                }`}
              >
                <div className="flex justify-between items-center w-full mb-2">
                  <span className="text-sm sm:text-base text-white font-medium">{market.name}</span>
                  <StatusBadge status={market.status} />
                </div>
                <div className="text-xl sm:text-2xl font-bold text-yellow-300 my-2">{market.result}</div>
                <div className="text-xs sm:text-sm text-white">{market.time} WIB</div>
              </Card>
            </motion.div>
          ))}
        </div>
      </motion.div>
    </div>
  )
}

function StatusBadge({ status }: { status: "open" | "closed" | "live" }) {
  if (status === "live") {
    return <Badge className="bg-red-600 hover:bg-red-700 text-xs animate-pulse text-white font-medium">LIVE</Badge>
  }

  if (status === "open") {
    return <Badge className="bg-green-600 hover:bg-green-700 text-xs text-white font-medium">OPEN</Badge>
  }

  return <Badge className="bg-gray-600 hover:bg-gray-700 text-xs text-white font-medium">CLOSED</Badge>
}
