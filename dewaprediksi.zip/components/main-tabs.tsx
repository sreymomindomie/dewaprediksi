"use client"

import { useState, useRef, useEffect } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { LiveDrawSection } from "@/components/sections/live-draw-section"
import { PaitoSection } from "@/components/sections/paito-section"
import { PredictionSection } from "@/components/sections/prediction-section"
import { BocorSection } from "@/components/sections/bocor-section"
import { PoolsSection } from "@/components/sections/pools-section"
import { motion } from "framer-motion"

export function MainTabs() {
  const [activeTab, setActiveTab] = useState("live-draw")
  const tabsListRef = useRef<HTMLDivElement>(null)

  // Scroll active tab into view when it changes
  useEffect(() => {
    if (tabsListRef.current) {
      const activeTabElement = tabsListRef.current.querySelector('[data-state="active"]')
      if (activeTabElement) {
        const tabsListRect = tabsListRef.current.getBoundingClientRect()
        const activeTabRect = activeTabElement.getBoundingClientRect()

        // Calculate the scroll position to center the active tab
        const scrollLeft = activeTabRect.left - tabsListRect.left - tabsListRect.width / 2 + activeTabRect.width / 2

        tabsListRef.current.scrollTo({
          left: scrollLeft,
          behavior: "smooth",
        })
      }
    }
  }, [activeTab])

  const tabIcons = {
    "live-draw": (
      <svg
        xmlns="http://www.w3.org/2000/svg"
        className="h-4 w-4 sm:h-5 sm:w-5 mb-1 sm:mb-0 sm:mr-2"
        fill="none"
        viewBox="0 0 24 24"
        stroke="currentColor"
      >
        <path
          strokeLinecap="round"
          strokeLinejoin="round"
          strokeWidth={2}
          d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z"
        />
      </svg>
    ),
    paito: (
      <svg
        xmlns="http://www.w3.org/2000/svg"
        className="h-4 w-4 sm:h-5 sm:w-5 mb-1 sm:mb-0 sm:mr-2"
        fill="none"
        viewBox="0 0 24 24"
        stroke="currentColor"
      >
        <path
          strokeLinecap="round"
          strokeLinejoin="round"
          strokeWidth={2}
          d="M9 17V7m0 10a2 2 0 01-2 2H5a2 2 0 01-2-2V7a2 2 0 012-2h2a2 2 0 012 2m0 10a2 2 0 002 2h2a2 2 0 002-2M9 7a2 2 0 012-2h2a2 2 0 012 2m0 10V7m0 10a2 2 0 002 2h2a2 2 0 002-2V7a2 2 0 00-2-2h-2a2 2 0 00-2 2"
        />
      </svg>
    ),
    prediction: (
      <svg
        xmlns="http://www.w3.org/2000/svg"
        className="h-4 w-4 sm:h-5 sm:w-5 mb-1 sm:mb-0 sm:mr-2"
        fill="none"
        viewBox="0 0 24 24"
        stroke="currentColor"
      >
        <path
          strokeLinecap="round"
          strokeLinejoin="round"
          strokeWidth={2}
          d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z"
        />
      </svg>
    ),
    bocoran: (
      <svg
        xmlns="http://www.w3.org/2000/svg"
        className="h-4 w-4 sm:h-5 sm:w-5 mb-1 sm:mb-0 sm:mr-2"
        fill="none"
        viewBox="0 0 24 24"
        stroke="currentColor"
      >
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
      </svg>
    ),
    pools: (
      <svg
        xmlns="http://www.w3.org/2000/svg"
        className="h-4 w-4 sm:h-5 sm:w-5 mb-1 sm:mb-0 sm:mr-2"
        fill="none"
        viewBox="0 0 24 24"
        stroke="currentColor"
      >
        <path
          strokeLinecap="round"
          strokeLinejoin="round"
          strokeWidth={2}
          d="M21 12a9 9 0 01-9 9m9-9a9 9 0 00-9-9m9 9H3m9 9a9 9 0 01-9-9m9 9c1.657 0 3-4.03 3-9s-1.343-9-3-9m0 18c-1.657 0-3-4.03-3-9s1.343-9 3-9m-9 9a9 9 0 019-9"
        />
      </svg>
    ),
  }

  return (
    <div className="container mx-auto px-2 sm:px-4">
      <Tabs defaultValue="live-draw" className="w-full" onValueChange={setActiveTab}>
        <div className="sticky top-0 z-30 bg-gradient-to-r from-purple-900 to-indigo-900 py-2 sm:py-4 shadow-lg">
          <div className="tabs-list-container" ref={tabsListRef}>
            <TabsList className="h-auto sm:h-16 flex w-full bg-gradient-to-r from-purple-900/70 to-indigo-900/70 p-1 rounded-xl">
              {Object.entries(tabIcons).map(([value, icon]) => (
                <TabsTrigger
                  key={value}
                  value={value}
                  className={`relative z-10 flex flex-col sm:flex-row items-center justify-center py-2 sm:py-3 px-2 sm:px-4 transition-all duration-300 text-xs sm:text-base font-medium flex-1 min-w-[70px] sm:min-w-0 ${
                    activeTab === value
                      ? "text-white data-[state=active]:bg-transparent"
                      : "text-white/80 hover:text-white"
                  }`}
                >
                  {icon}
                  <span className="sm:ml-2">
                    {value
                      .split("-")
                      .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
                      .join(" ")}
                  </span>
                  {activeTab === value && (
                    <motion.div
                      layoutId="activeTabIndicator"
                      className="absolute inset-0 bg-gradient-to-r from-purple-600/80 via-indigo-600/80 to-purple-600/80 rounded-lg"
                      style={{ zIndex: -1 }}
                      transition={{ type: "spring", duration: 0.5 }}
                    />
                  )}
                </TabsTrigger>
              ))}
            </TabsList>
          </div>
        </div>

        <div className="mt-4 sm:mt-6">
          <TabsContent value="live-draw">
            <LiveDrawSection />
          </TabsContent>
          <TabsContent value="paito">
            <PaitoSection />
          </TabsContent>
          <TabsContent value="prediction">
            <PredictionSection />
          </TabsContent>
          <TabsContent value="bocoran">
            <BocorSection />
          </TabsContent>
          <TabsContent value="pools">
            <PoolsSection />
          </TabsContent>
        </div>
      </Tabs>
    </div>
  )
}
