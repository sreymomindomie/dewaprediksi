"use client"

import * as React from "react"
import { cn } from "@/lib/utils"

const Textarea = React.forwardRef<HTMLTextAreaElement, React.TextareaHTMLAttributes<HTMLTextAreaElement>>(
  ({ className, ...props }, ref) => {
    // Create a ref if one isn't provided
    const innerRef = React.useRef<HTMLTextAreaElement>(null)
    const resolvedRef = ref || innerRef

    // Use useEffect to handle any browser extension modifications
    React.useEffect(() => {
      // This runs only on the client after hydration
      // By this point, React has already "accepted" any differences
    }, [])

    return (
      <textarea
        className={cn(
          "flex min-h-[80px] w-full rounded-md border border-input bg-background px-3 py-2 text-base ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 md:text-sm",
          className,
        )}
        ref={resolvedRef}
        {...props}
      />
    )
  },
)
Textarea.displayName = "Textarea"

export { Textarea }
