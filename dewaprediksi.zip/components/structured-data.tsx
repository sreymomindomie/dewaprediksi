export function StructuredData() {
  const websiteSchema = {
    "@context": "https://schema.org",
    "@type": "WebSite",
    name: "Dewa Prediksi",
    url: "https://dewaprediksi.com",
    potentialAction: {
      "@type": "SearchAction",
      target: "https://dewaprediksi.com/search?q={search_term_string}",
      "query-input": "required name=search_term_string",
    },
  }

  const organizationSchema = {
    "@context": "https://schema.org",
    "@type": "Organization",
    name: "Dewa Prediksi",
    url: "https://dewaprediksi.com",
    logo: "https://dewaprediksi.com/logo.png",
    sameAs: [
      "https://facebook.com/dewaprediksi",
      "https://twitter.com/dewaprediksi",
      "https://instagram.com/dewaprediksi",
    ],
  }

  const breadcrumbSchema = {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    itemListElement: [
      {
        "@type": "ListItem",
        position: 1,
        name: "Beranda",
        item: "https://dewaprediksi.com",
      },
      {
        "@type": "ListItem",
        position: 2,
        name: "Prediksi Togel",
        item: "https://dewaprediksi.com/prediksi",
      },
    ],
  }

  const faqSchema = {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    mainEntity: [
      {
        "@type": "Question",
        name: "Apa itu Dewa Prediksi?",
        acceptedAnswer: {
          "@type": "Answer",
          text: "Dewa Prediksi adalah platform ramalan togel terpercaya yang memberikan prediksi angka jitu untuk berbagai pasaran togel seperti Hongkong, Singapore, Sydney, dan lainnya.",
        },
      },
      {
        "@type": "Question",
        name: "Bagaimana cara mendapatkan prediksi togel?",
        acceptedAnswer: {
          "@type": "Answer",
          text: "Anda cukup mengunjungi website Dewa Prediksi dan mengisi form prediksi dengan detail yang diminta. Sistem kami akan menganalisis data tersebut dan memberikan angka prediksi yang akurat.",
        },
      },
      {
        "@type": "Question",
        name: "Apakah prediksi dari Dewa Prediksi akurat?",
        acceptedAnswer: {
          "@type": "Answer",
          text: "Dewa Prediksi menggunakan algoritma canggih dan analisis mendalam untuk memberikan prediksi dengan tingkat akurasi tinggi. Namun, hasil togel tetap bergantung pada faktor keberuntungan.",
        },
      },
    ],
  }

  return (
    <>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(websiteSchema) }} />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(organizationSchema) }} />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbSchema) }} />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(faqSchema) }} />
    </>
  )
}
