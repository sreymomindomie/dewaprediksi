"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { motion, AnimatePresence } from "framer-motion"
import { MessageCircle, X, Phone, Gift, HelpCircle, Download } from "lucide-react"

export function FloatingActionButton() {
  const [isOpen, setIsOpen] = useState(false)

  const toggleOpen = () => setIsOpen(!isOpen)

  const buttons = [
    {
      icon: <Phone className="h-4 w-4 sm:h-5 sm:w-5" />,
      label: "Hubungi Kami",
      color: "bg-green-500 hover:bg-green-600",
    },
    {
      icon: <Gift className="h-4 w-4 sm:h-5 sm:w-5" />,
      label: "Bonus & Promo",
      color: "bg-yellow-500 hover:bg-yellow-600",
    },
    {
      icon: <HelpCircle className="h-4 w-4 sm:h-5 sm:w-5" />,
      label: "Bantuan",
      color: "bg-blue-500 hover:bg-blue-600",
    },
    {
      icon: <Download className="h-4 w-4 sm:h-5 sm:w-5" />,
      label: "Unduh Aplikasi",
      color: "bg-purple-500 hover:bg-purple-600",
    },
  ]

  return (
    <div className="fixed bottom-3 sm:bottom-6 right-3 sm:right-6 z-50">
      <AnimatePresence>
        {isOpen && (
          <div className="absolute bottom-12 sm:bottom-16 right-0 flex flex-col items-end space-y-2">
            {buttons.map((button, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20, scale: 0.8 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: 20, scale: 0.8 }}
                transition={{ duration: 0.2, delay: index * 0.05 }}
                className="flex items-center"
              >
                <div className="mr-2 bg-purple-900/90 text-white text-xs py-1 px-2 sm:py-2 sm:px-3 rounded-lg shadow-lg">
                  {button.label}
                </div>
                <Button
                  size="icon"
                  className={`rounded-full shadow-lg w-8 h-8 sm:w-10 sm:h-10 ${button.color}`}
                  onClick={() => {
                    // Handle button click
                    setIsOpen(false)
                  }}
                >
                  {button.icon}
                </Button>
              </motion.div>
            ))}
          </div>
        )}
      </AnimatePresence>

      <motion.div whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.9 }}>
        <Button
          size="icon"
          className={`rounded-full shadow-lg w-10 h-10 sm:w-12 sm:h-12 ${
            isOpen ? "bg-red-500 hover:bg-red-600" : "bg-gradient-to-r from-purple-600 to-pink-600"
          }`}
          onClick={toggleOpen}
        >
          {isOpen ? <X className="h-4 w-4 sm:h-5 sm:w-5" /> : <MessageCircle className="h-4 w-4 sm:h-5 sm:w-5" />}
        </Button>
      </motion.div>
    </div>
  )
}
