"use client"

import { useState, useEffect } from "react"
import { Loader2, CheckCircle, XCircle, AlertTriangle } from "lucide-react"
import { Progress } from "@/components/ui/progress"
import { Button } from "@/components/ui/button"

interface WhatsAppVerificationProps {
  phoneNumber: string
  onVerificationComplete: (isVerified: boolean) => void
}

export function WhatsAppVerification({ phoneNumber, onVerificationComplete }: WhatsAppVerificationProps) {
  const [status, setStatus] = useState<"confirm" | "pending" | "verifying" | "success" | "error">("confirm")
  const [progress, setProgress] = useState(0)
  const [isDrawing, setIsDrawing] = useState(false)
  const [formattedNumber, setFormattedNumber] = useState("")
  const [verificationAttempted, setVerificationAttempted] = useState(false)

  // Format the phone number when it changes
  useEffect(() => {
    if (!phoneNumber) return

    let formatted = phoneNumber
    if (phoneNumber.startsWith("0")) {
      formatted = `62${phoneNumber.substring(1)}`
    } else if (!phoneNumber.startsWith("62")) {
      formatted = `62${phoneNumber}`
    }

    setFormattedNumber(formatted)
  }, [phoneNumber])

  const startVerification = async () => {
    // If we've already attempted verification for this number, don't do it again
    if (verificationAttempted) {
      return
    }

    try {
      setStatus("verifying")
      setProgress(0)
      setVerificationAttempted(true)

      // Simulate progress for better UX
      const progressInterval = setInterval(() => {
        setProgress((prev) => {
          if (prev >= 90) {
            clearInterval(progressInterval)
            return prev
          }
          return prev + 10
        })
      }, 500)

      try {
        const response = await fetch(`/api/auth/verify-whatsapp?phoneNumber=${formattedNumber}`)
        const data = await response.json()

        clearInterval(progressInterval)
        setProgress(100)

        if (data.isVerified) {
          setStatus("success")
          onVerificationComplete(true)
        } else {
          setStatus("error")
          onVerificationComplete(false)
        }
      } catch (apiError) {
        console.error("API call error:", apiError)
        clearInterval(progressInterval)
        setProgress(100)

        // Check if the number format is valid as a fallback
        const isValidFormat = /^62[8][1-9][0-9]{6,10}$/.test(formattedNumber)

        if (isValidFormat) {
          setStatus("success")
          onVerificationComplete(true)
        } else {
          setStatus("error")
          onVerificationComplete(false)
        }
      }
    } catch (error) {
      console.error("WhatsApp verification error:", error)
      setStatus("error")
      onVerificationComplete(false)
    }
  }

  // Format for display (add spaces for readability)
  const getDisplayNumber = () => {
    if (!formattedNumber) return ""

    // Format: 62 812 3456 7890
    const parts = [
      formattedNumber.substring(0, 2),
      formattedNumber.substring(2, 5),
      formattedNumber.substring(5, 9),
      formattedNumber.substring(9),
    ]

    return parts.filter((part) => part.length > 0).join(" ")
  }

  return (
    <div
      className={`p-3 sm:p-4 rounded-lg border ${
        status === "confirm"
          ? "bg-purple-800/30 border-purple-500/30"
          : status === "success"
            ? "bg-green-800/30 border-green-500/30"
            : status === "error"
              ? "bg-red-800/30 border-red-500/30"
              : "bg-purple-800/30 border-purple-500/30"
      }`}
    >
      <div className="flex items-center mb-2">
        {status === "confirm" ? (
          <AlertTriangle className="h-4 w-4 sm:h-5 sm:w-5 mr-2 text-yellow-400" />
        ) : status === "pending" || status === "verifying" ? (
          <Loader2 className="h-4 w-4 sm:h-5 sm:w-5 mr-2 animate-spin text-yellow-400" />
        ) : status === "success" ? (
          <CheckCircle className="h-4 w-4 sm:h-5 sm:w-5 mr-2 text-green-400" />
        ) : (
          <XCircle className="h-4 w-4 sm:h-5 sm:w-5 mr-2 text-red-400" />
        )}
        <p className="text-white text-sm">
          {status === "confirm"
            ? "Konfirmasi nomor WhatsApp Anda"
            : status === "verifying"
              ? "Memeriksa nomor WhatsApp Anda..."
              : status === "success"
                ? "Nomor WhatsApp terverifikasi!"
                : "Nomor tidak terdaftar di WhatsApp. Pastikan nomor Anda aktif di WhatsApp."}
        </p>
      </div>

      {status === "confirm" && (
        <div className="mt-2">
          <p className="text-white text-xs sm:text-sm mb-2">Apakah nomor ini sudah benar?</p>
          <p className="text-yellow-300 font-medium mb-3 text-sm sm:text-base">{getDisplayNumber()}</p>
          <div className="flex gap-2">
            <Button
              variant="outline"
              size="sm"
              className="bg-transparent border-red-500/50 text-white hover:bg-red-900/30 text-xs h-8 sm:h-9"
              onClick={() => {
                setStatus("error")
                onVerificationComplete(false)
              }}
            >
              Belum Benar
            </Button>
            <Button
              size="sm"
              className="bg-gradient-to-r from-green-600 to-green-500 hover:from-green-700 hover:to-green-600 text-white text-xs h-8 sm:h-9"
              onClick={startVerification}
            >
              Sudah Benar
            </Button>
          </div>
        </div>
      )}

      {(status === "pending" || status === "verifying") && (
        <Progress
          value={progress}
          className="h-1.5 sm:h-2 mt-2"
          indicatorClassName="bg-gradient-to-r from-yellow-500 to-yellow-300"
        />
      )}
    </div>
  )
}
