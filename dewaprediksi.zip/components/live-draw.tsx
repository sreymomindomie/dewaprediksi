"use client"

import { useState, useEffect } from "react"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { motion, AnimatePresence } from "framer-motion"

interface LiveDrawProps {
  market: string
  drawTime: string
}

export function LiveDraw({ market, drawTime }: LiveDrawProps) {
  const [timeLeft, setTimeLeft] = useState("00:00:00")
  const [progress, setProgress] = useState(0)
  const [isDrawing, setIsDrawing] = useState(false)
  const [drawResult, setDrawResult] = useState<string | null>(null)
  const [currentDigit, setCurrentDigit] = useState(0)

  // Convert drawTime to target time
  useEffect(() => {
    const calculateTimeLeft = () => {
      try {
        const now = new Date()

        // Parse the time safely with fallbacks
        let hours = 0
        let minutes = 0

        // Check if drawTime is in the expected format
        if (drawTime && drawTime.includes(":")) {
          const timeParts = drawTime.split(":")
          // Safely parse hours and minutes with fallbacks
          hours = Number.parseInt(timeParts[0]) || 0
          minutes = Number.parseInt(timeParts[1]) || 0
        }

        // Create target time for today
        const targetTime = new Date(now)
        targetTime.setHours(hours, minutes, 0, 0)

        // If target time is in the past, set it to tomorrow
        if (targetTime < now) {
          targetTime.setDate(targetTime.getDate() + 1)
        }

        const difference = targetTime.getTime() - now.getTime()

        // Calculate progress (inverse percentage of time left until draw)
        const totalTimeUntilDraw = 24 * 60 * 60 * 1000 // 24 hours in milliseconds
        const progressValue = 100 - (difference / totalTimeUntilDraw) * 100
        setProgress(Math.max(0, Math.min(100, progressValue))) // Ensure progress is between 0-100

        // Format time left
        const hoursLeft = Math.floor(difference / (1000 * 60 * 60))
        const minutesLeft = Math.floor((difference % (1000 * 60 * 60)) / (1000 * 60))
        const secondsLeft = Math.floor((difference % (1000 * 60)) / 1000)

        return `${hoursLeft.toString().padStart(2, "0")}:${minutesLeft.toString().padStart(2, "0")}:${secondsLeft
          .toString()
          .padStart(2, "0")}`
      } catch (error) {
        console.error("Error calculating time left:", error)
        return "00:00:00" // Fallback to prevent NaN display
      }
    }

    // Initial calculation
    setTimeLeft(calculateTimeLeft())

    // Update every second
    const timer = setInterval(() => {
      const timeLeftStr = calculateTimeLeft()
      setTimeLeft(timeLeftStr)

      // Simulate drawing when time is up
      if (timeLeftStr === "00:00:00") {
        startDrawing()
      }
    }, 1000)

    return () => clearInterval(timer)
  }, [drawTime])

  // Simulate drawing process
  const startDrawing = () => {
    setIsDrawing(true)
    setDrawResult(null)
    setCurrentDigit(0)

    // Generate random 4D number
    const result = Array.from({ length: 4 }, () => Math.floor(Math.random() * 10)).join("")

    // Animate each digit
    let digit = 0
    const digitInterval = setInterval(() => {
      if (digit < 4) {
        setCurrentDigit(digit + 1)
        digit++
      } else {
        clearInterval(digitInterval)
        setDrawResult(result)
        setIsDrawing(false)
      }
    }, 1500)
  }

  return (
    <div className="space-y-4 sm:space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 sm:gap-4">
        <div>
          <h3 className="text-base sm:text-xl font-bold text-white mb-1">{market} Pools</h3>
          <div className="flex flex-wrap items-center gap-2 sm:gap-3">
            <Badge
              variant="outline"
              className="bg-purple-800/50 text-white border-purple-500/50 px-2 sm:px-3 py-0.5 sm:py-1 text-xs sm:text-sm"
            >
              {drawTime} WIB
            </Badge>
            <Badge
              variant="outline"
              className="bg-indigo-800/50 text-white border-indigo-500/50 px-2 sm:px-3 py-0.5 sm:py-1 text-xs sm:text-sm"
            >
              Live Draw
            </Badge>
          </div>
        </div>

        <div className="flex flex-col items-end mt-2 sm:mt-0">
          <div className="text-xs sm:text-sm text-white mb-1">Waktu Tersisa</div>
          <div className="text-base sm:text-xl font-bold text-yellow-300">{timeLeft}</div>
        </div>
      </div>

      <div className="bg-purple-900/30 rounded-lg p-3 sm:p-4 border border-purple-500/30">
        <div className="flex justify-between items-center mb-2">
          <div className="text-xs sm:text-sm text-white">Progress Menuju Live Draw</div>
          <div className="text-xs sm:text-sm text-white">{Math.round(progress)}%</div>
        </div>
        <Progress
          value={progress}
          className="h-1.5 sm:h-2 bg-purple-950"
          indicatorClassName="bg-gradient-to-r from-purple-500 to-indigo-500"
        />
      </div>

      <div className="bg-gradient-to-r from-purple-900/50 via-indigo-800/50 to-purple-900/50 rounded-lg p-3 sm:p-6 border border-purple-500/30 flex flex-col items-center">
        <h4 className="text-base sm:text-lg font-bold text-white mb-3 sm:mb-4">Hasil Live Draw {market}</h4>

        <div className="grid grid-cols-4 gap-2 sm:gap-4 mb-3 sm:mb-4">
          {Array.from({ length: 4 }).map((_, index) => (
            <div
              key={index}
              className="w-14 sm:w-16 h-16 sm:h-20 bg-gradient-to-b from-purple-800 to-purple-900 rounded-lg border border-purple-500/50 flex items-center justify-center relative overflow-hidden"
            >
              <AnimatePresence>
                {isDrawing && currentDigit > index ? (
                  <motion.div
                    initial={{ y: 40, opacity: 0 }}
                    animate={{ y: 0, opacity: 1 }}
                    exit={{ y: -40, opacity: 0 }}
                    transition={{ duration: 0.5 }}
                    className="text-2xl sm:text-3xl font-bold text-yellow-300"
                  >
                    {Math.floor(Math.random() * 10)}
                  </motion.div>
                ) : drawResult ? (
                  <motion.div
                    initial={{ scale: 0.5, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    transition={{ duration: 0.3, delay: index * 0.1 }}
                    className="text-2xl sm:text-3xl font-bold text-yellow-300"
                  >
                    {drawResult[index]}
                  </motion.div>
                ) : (
                  <div className="text-2xl sm:text-3xl font-bold text-gray-600">?</div>
                )}
              </AnimatePresence>

              {/* Animated dots for loading effect */}
              {isDrawing && currentDigit <= index && (
                <div className="absolute bottom-2 flex space-x-1">
                  <motion.div
                    animate={{ opacity: [0.2, 1, 0.2] }}
                    transition={{ duration: 1, repeat: Number.POSITIVE_INFINITY, delay: 0 }}
                    className="w-1 h-1 sm:w-1.5 sm:h-1.5 bg-yellow-300 rounded-full"
                  />
                  <motion.div
                    animate={{ opacity: [0.2, 1, 0.2] }}
                    transition={{ duration: 1, repeat: Number.POSITIVE_INFINITY, delay: 0.3 }}
                    className="w-1 h-1 sm:w-1.5 sm:h-1.5 bg-yellow-300 rounded-full"
                  />
                  <motion.div
                    animate={{ opacity: [0.2, 1, 0.2] }}
                    transition={{ duration: 1, repeat: Number.POSITIVE_INFINITY, delay: 0.6 }}
                    className="w-1 h-1 sm:w-1.5 sm:h-1.5 bg-yellow-300 rounded-full"
                  />
                </div>
              )}
            </div>
          ))}
        </div>

        <div className="text-xs sm:text-sm text-white text-center">
          {isDrawing ? (
            <span className="text-yellow-300">Sedang melakukan pengundian...</span>
          ) : drawResult ? (
            <span>Hasil undian telah ditetapkan</span>
          ) : (
            <span>Menunggu waktu pengundian</span>
          )}
        </div>
      </div>
    </div>
  )
}
