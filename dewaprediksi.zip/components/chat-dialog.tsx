"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogTitle } from "@/components/ui/dialog"
import { MessageCircle } from "lucide-react"
import ChatConsultationWrapper from "@/components/chat-consultation-wrapper"

export function ChatDialog() {
  const [isOpen, setIsOpen] = useState(false)

  return (
    <>
      <Button
        onClick={() => setIsOpen(true)}
        className="fixed bottom-16 sm:bottom-24 right-3 sm:right-6 z-40 rounded-full h-10 w-10 sm:h-14 sm:w-14 bg-gradient-to-r from-yellow-600 to-amber-600 hover:from-yellow-700 hover:to-amber-700 shadow-lg"
      >
        <MessageCircle className="h-5 w-5 sm:h-6 sm:w-6" />
        <span className="sr-only">Chat dengan Dewa Prediksi</span>
      </Button>

      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogContent className="max-w-[95vw] sm:max-w-[90vw] md:max-w-[600px] h-[90vh] sm:h-[80vh] p-0 bg-transparent border-none">
          <DialogTitle className="sr-only">Chat dengan Dewa Prediksi</DialogTitle>
          <ChatConsultationWrapper />
        </DialogContent>
      </Dialog>
    </>
  )
}
