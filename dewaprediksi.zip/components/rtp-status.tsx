"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { AlertTriangle, TrendingUp } from "lucide-react"
import { motion } from "framer-motion"
import { generateRandomPercentage, generateRandomElapsedTime } from "@/components/utils/random-generator"

type Market = {
  name: string
  status: "bocor" | "normal" | "hot"
  percentage: number
  lastUpdate: string
}

export function RtpStatus() {
  const [markets, setMarkets] = useState<Market[]>([])

  // Inisialisasi data RTP secara acak
  useEffect(() => {
    const marketNames = ["Hongkong", "Sidney", "Singapore", "Macau", "Taiwan"]

    const randomMarkets: Market[] = marketNames.map((name) => {
      const percentage = generateRandomPercentage(50, 95)
      let status: "bocor" | "normal" | "hot" = "normal"

      if (percentage > 85) status = "bocor"
      else if (percentage > 75) status = "hot"

      return {
        name,
        status,
        percentage,
        lastUpdate: generateRandomElapsedTime(),
      }
    })

    setMarkets(randomMarkets)
  }, [])

  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  }

  const item = {
    hidden: { opacity: 0, x: -20 },
    show: { opacity: 1, x: 0 },
  }

  return (
    // Update the RTP status for better mobile viewing
    <Card className="bg-gradient-to-br from-purple-800/50 via-indigo-800/50 to-purple-800/50 backdrop-blur-md border-purple-500/30 h-full shadow-lg overflow-hidden">
      <CardHeader className="pb-2 bg-gradient-to-r from-purple-800/50 to-indigo-800/50">
        <CardTitle className="text-white flex items-center text-base sm:text-lg">
          <TrendingUp className="mr-2 h-4 w-4 sm:h-5 sm:w-5 text-yellow-400" />
          Status RTP Hari Ini
        </CardTitle>
      </CardHeader>
      <CardContent>
        <motion.div className="space-y-3 sm:space-y-4" variants={container} initial="hidden" animate="show">
          {markets.map((market) => (
            <motion.div key={market.name} className="space-y-1" variants={item}>
              <div className="flex justify-between items-center">
                <span className="text-sm sm:text-base text-white font-medium">{market.name}</span>
                <StatusBadge status={market.status} />
              </div>
              <div className="relative h-2 bg-purple-950 rounded-full overflow-hidden">
                <motion.div
                  className={`absolute top-0 left-0 h-full rounded-full ${
                    market.status === "bocor"
                      ? "bg-gradient-to-r from-green-500 to-green-400"
                      : market.status === "hot"
                        ? "bg-gradient-to-r from-yellow-500 to-yellow-400"
                        : "bg-gradient-to-r from-blue-500 to-blue-400"
                  }`}
                  initial={{ width: 0 }}
                  animate={{ width: `${market.percentage}%` }}
                  transition={{ duration: 1, ease: "easeOut" }}
                />
              </div>
              <div className="flex justify-between text-xs">
                <span className="text-purple-300">{market.percentage}% RTP</span>
                <span className="text-purple-300">{market.lastUpdate}</span>
              </div>
            </motion.div>
          ))}
        </motion.div>

        <div className="mt-3 sm:mt-4 pt-3 sm:pt-4 border-t border-purple-700/30">
          <div className="flex items-center text-yellow-300 text-xs sm:text-sm">
            <AlertTriangle className="h-3 w-3 sm:h-4 sm:w-4 mr-1 sm:mr-2" />
            <span>RTP "Bocor" menandakan peluang menang lebih tinggi!</span>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

function StatusBadge({ status }: { status: "bocor" | "normal" | "hot" }) {
  if (status === "bocor") {
    return (
      <Badge className="bg-gradient-to-r from-green-600 to-green-500 hover:from-green-700 hover:to-green-600 animate-pulse">
        Lagi Bocor
      </Badge>
    )
  }

  if (status === "hot") {
    return (
      <Badge className="bg-gradient-to-r from-yellow-600 to-yellow-500 hover:from-yellow-700 hover:to-yellow-600">
        Hot
      </Badge>
    )
  }

  return (
    <Badge className="bg-gradient-to-r from-blue-600 to-blue-500 hover:from-blue-700 hover:to-blue-600">Normal</Badge>
  )
}
