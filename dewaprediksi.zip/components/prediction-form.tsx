"use client"
import { useState, useEffect, useRef } from "react"
import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import { z } from "zod"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Loader2, Phone, Lock, Eye, EyeOff, AlertTriangle, Sparkles, X } from "lucide-react"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogClose,
} from "@/components/ui/dialog"
import { Badge } from "@/components/ui/badge"
import { Checkbox } from "@/components/ui/checkbox"
import { motion, AnimatePresence } from "framer-motion"
import { ToggleGroup, ToggleGroupItem } from "@/components/ui/toggle-group"
import axios from "axios"
import { generateTimestamp, generateFingerprint, generateSignature } from "@/utils/security"
import { WhatsAppVerification } from "@/components/whatsapp-verification"

const phoneRegex = /^(\+62|62|0)8[1-9][0-9]{6,9}$/

const registrationSchema = z.object({
  phoneNumber: z.string().regex(phoneRegex, {
    message: "Nomor HP tidak valid. Gunakan format: 08xxxxxxxxx",
  }),
  fullName: z.string().min(3, {
    message: "Nama lengkap minimal 3 karakter",
  }),
  password: z.string().min(6, {
    message: "Password minimal 6 karakter",
  }),
  agreeTerms: z.literal(true, {
    errorMap: () => ({ message: "Anda harus menyetujui syarat dan ketentuan" }),
  }),
})

const loginSchema = z.object({
  phoneNumber: z.string().regex(phoneRegex, {
    message: "Nomor HP tidak valid. Gunakan format: 08xxxxxxxxx",
  }),
  password: z.string().min(1, {
    message: "Password harus diisi",
  }),
})

const predictionSchema = z.object({
  predictionType: z.string().min(1, {
    message: "Pilih jenis prediksi",
  }),
  predictionInput: z.string().min(3, {
    message: "Input prediksi harus minimal 3 karakter",
  }),
  market: z.string().min(1, {
    message: "Pilih pasaran togel",
  }),
  outputType: z.string().default("4D"),
})

export function PredictionForm() {
  const [isLoggedIn, setIsLoggedIn] = useState(false)
  const [showPassword, setShowPassword] = useState(false)
  const [result, setResult] = useState<string | null>(null)
  const [aiResponse, setAiResponse] = useState<string | null>(null)
  const [isLoading, setIsLoading] = useState(false)
  const [userData, setUserData] = useState<{
    phoneNumber: string
    fullName: string
    isWhatsappVerified?: boolean
  } | null>(null)
  const [showLoginDialog, setShowLoginDialog] = useState(false)
  const [predictionHistory, setPredictionHistory] = useState<
    Array<{
      date: string
      type: string
      input: string
      result: string
      outputType: string
    }>
  >([])
  const [isGenerating, setIsGenerating] = useState(false)
  const [generationProgress, setGenerationProgress] = useState(0)
  const [outputType, setOutputType] = useState("4D")
  const [imageResult, setImageResult] = useState<string | null>(null)
  const [isVerifyingWhatsApp, setIsVerifyingWhatsApp] = useState(false)
  const [whatsAppVerified, setWhatsAppVerified] = useState(false)
  const [verificationMessage, setVerificationMessage] = useState("")
  const [phoneToVerify, setPhoneToVerify] = useState<string | null>(null)
  const verifiedNumbers = useRef<Set<string>>(new Set())
  const predictionTypes = [
    "Mimpi",
    "Kejadian Sehari-hari",
    "Tanggal Lahir",
    "Plat Nomor",
    "Nomor Rumah",
    "Nama",
    "Benda yang Ditemukan",
    "Peristiwa Alam",
    "Kecelakaan",
    "Pertemuan",
    "Lainnya",
  ]
  const markets = ["Hongkong", "Singapore", "Sydney", "Macau", "Taiwan", "Cambodia", "China", "Japan", "Korea", "Laos"]
  const registrationForm = useForm<z.infer<typeof registrationSchema>>({
    resolver: zodResolver(registrationSchema),
    defaultValues: {
      phoneNumber: "",
      fullName: "",
      password: "",
      agreeTerms: false,
    },
  })
  const loginForm = useForm<z.infer<typeof loginSchema>>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      phoneNumber: "",
      password: "",
    },
  })
  const predictionForm = useForm<z.infer<typeof predictionSchema>>({
    resolver: zodResolver(predictionSchema),
    defaultValues: {
      predictionType: "",
      predictionInput: "",
      market: "",
      outputType: "4D",
    },
  })

  useEffect(() => {
    if (typeof window !== "undefined") {
      const savedUser = localStorage.getItem("rtpUserData")
      if (savedUser) {
        try {
          const parsedUser = JSON.parse(savedUser)
          setUserData(parsedUser)
          setIsLoggedIn(true)

          const savedHistory = localStorage.getItem(`predictionHistory_${parsedUser.phoneNumber}`)
          if (savedHistory) {
            setPredictionHistory(JSON.parse(savedHistory))
          }
        } catch (e) {
          console.error("Error parsing user data:", e)
        }
      } else {
        setShowLoginDialog(true)
      }
    }
  }, [])

  const handlePhoneVerification = (isVerified: boolean) => {
    setWhatsAppVerified(isVerified)
    if (!isVerified) {
      registrationForm.setError("phoneNumber", {
        type: "manual",
        message: "Nomor tidak valid atau tidak terdaftar di WhatsApp",
      })
    }
  }

  const startWhatsAppVerification = (phoneNumber: string) => {
    if (phoneNumber && phoneNumber.length >= 10) {
      let formattedNumber = phoneNumber
      if (phoneNumber.startsWith("0")) {
        formattedNumber = `62${phoneNumber.substring(1)}`
      } else if (!phoneNumber.startsWith("62")) {
        formattedNumber = `62${phoneNumber}`
      }

      if (verifiedNumbers.current.has(formattedNumber)) {
        console.log(`Number ${formattedNumber} already verified, skipping verification`)
        setWhatsAppVerified(true)
        return
      }

      registrationForm.clearErrors("phoneNumber")
      setPhoneToVerify(phoneNumber)
    } else if (phoneNumber) {
      registrationForm.setError("phoneNumber", {
        type: "manual",
        message: "Nomor terlalu pendek, minimal 10 digit",
      })
    }
  }

  const onRegister = async (values: z.infer<typeof registrationSchema>) => {
    setIsLoading(true)

    if (!whatsAppVerified) {
      setIsLoading(false)
      registrationForm.setError("phoneNumber", {
        type: "manual",
        message: "Nomor tidak terdaftar di WhatsApp",
      })
      return
    }

    try {
      const response = await fetch("/api/auth/register", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          phoneNumber: values.phoneNumber,
          fullName: values.fullName,
          password: values.password,
        }),
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || "Registration failed")
      }

      let formattedNumber = values.phoneNumber
      if (values.phoneNumber.startsWith("0")) {
        formattedNumber = `62${values.phoneNumber.substring(1)}`
      } else if (!values.phoneNumber.startsWith("62")) {
        formattedNumber = `62${values.phoneNumber}`
      }

      verifiedNumbers.current.add(formattedNumber)

      const userData = {
        phoneNumber: values.phoneNumber,
        fullName: values.fullName,
        isWhatsappVerified: true,
      }

      localStorage.setItem("rtpUserData", JSON.stringify(userData))
      localStorage.setItem("rtpUserPassword", values.password)

      setUserData(userData)
      setIsLoggedIn(true)
      setShowLoginDialog(false)
    } catch (error) {
      console.error("Registration error:", error)

      registrationForm.setError("root", {
        type: "manual",
        message: "Terjadi kesalahan saat mendaftar",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const onLogin = async (values: z.infer<typeof loginSchema>) => {
    setIsLoading(true)

    try {
      const response = await fetch("/api/auth/login", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          phoneNumber: values.phoneNumber,
          password: values.password,
        }),
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || "Login failed")
      }

      let formattedNumber = values.phoneNumber
      if (values.phoneNumber.startsWith("0")) {
        formattedNumber = `62${values.phoneNumber.substring(1)}`
      } else if (!values.phoneNumber.startsWith("62")) {
        formattedNumber = `62${values.phoneNumber}`
      }

      verifiedNumbers.current.add(formattedNumber)

      const userData = {
        phoneNumber: data.user.phoneNumber,
        fullName: data.user.fullName,
        isWhatsappVerified: data.user.isWhatsappVerified,
      }

      localStorage.setItem("rtpUserData", JSON.stringify(userData))
      localStorage.setItem("rtpUserPassword", values.password)

      setUserData(userData)
      setIsLoggedIn(true)
      setShowLoginDialog(false)

      const savedHistory = localStorage.getItem(`predictionHistory_${userData.phoneNumber}`)
      if (savedHistory) {
        setPredictionHistory(JSON.parse(savedHistory))
      }
    } catch (error) {
      console.error("Login error:", error)

      loginForm.setError("password", {
        type: "manual",
        message: "Nomor HP atau password salah",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const handleLogout = () => {
    // Clear all user-related data from localStorage
    localStorage.removeItem("rtpUserData")
    localStorage.removeItem("rtpUserPassword")

    // Clear any prediction history
    if (userData && userData.phoneNumber) {
      localStorage.removeItem(`predictionHistory_${userData.phoneNumber}`)
    }

    // Reset state
    setIsLoggedIn(false)
    setUserData(null)
    setPredictionHistory([])
    setShowLoginDialog(true)

    // Reset forms
    registrationForm.reset()
    loginForm.reset()
    predictionForm.reset()

    // Force a page reload to ensure all state is cleared
    window.location.reload()
  }

  const generateRandomNumberByType = (type: string) => {
    switch (type) {
      case "2D":
        return Math.floor(10 + Math.random() * 90).toString()
      case "3D":
        return Math.floor(100 + Math.random() * 900).toString()
      case "4D":
        return Math.floor(1000 + Math.random() * 9000).toString()
      case "BBFS":
        return Array.from({ length: 6 }, () => Math.floor(Math.random() * 10)).join("")
      case "Colok Bebas":
        return Math.floor(Math.random() * 10).toString()
      case "Colok Jitu":
        const pos = ["AS", "KOP", "KEPALA", "EKOR"][Math.floor(Math.random() * 4)]
        const num = Math.floor(Math.random() * 10)
        return `${pos}-${num}`
      case "Shio":
        const shios = [
          "Tikus",
          "Kerbau",
          "Harimau",
          "Kelinci",
          "Naga",
          "Ular",
          "Kuda",
          "Kambing",
          "Monyet",
          "Ayam",
          "Anjing",
          "Babi",
        ]
        return shios[Math.floor(Math.random() * shios.length)]
      default:
        return Math.floor(1000 + Math.random() * 9000).toString()
    }
  }

  const generateRandomDate = () => {
    const today = new Date()
    const pastDate = new Date(today)
    pastDate.setDate(today.getDate() - Math.floor(Math.random() * 7))
    return pastDate.toLocaleDateString("id-ID", { day: "2-digit", month: "2-digit", year: "numeric" })
  }

  const generatePredictionResponse = async (type: string, input: string, result: string, outputType: string) => {
    try {
      const timestamp = generateTimestamp()
      const fingerprint = generateFingerprint()
      const requestData = {
        id: userData?.phoneNumber || "guest-user",
        text: `${type}: ${input}. Berikan interpretasi mistis singkat tentang ${outputType}: ${result}`,
        timestamp: timestamp,
        fingerprint: fingerprint,
      }
      const signature = generateSignature(requestData, "dewaprediksi-secret-salt")
      const response = await axios.post(
        "/api/prediction",
        {
          ...requestData,
          signature: signature,
        },
        {
          headers: {
            "Content-Type": "application/json",
            "X-Request-Timestamp": timestamp,
            "X-Request-Signature": signature,
          },
        },
      )

      if (response.data && response.data.data && response.data.data.image) {
        setImageResult(response.data.data.image)
      }

      let message = ""
      if (response.data && response.data.data && response.data.data.message) {
        message = response.data.data.message
      } else if (response.data && response.data.result) {
        message = response.data.result
      }

      if (message) {
        return message
      }

      return `Berdasarkan ${type.toLowerCase()} "${input}", angka ${result} muncul sebagai simbol penting. 

Angka ini membawa energi kebijaksanaan dan transformasi dalam tradisi spiritual. 

Perhatikan kemunculannya dalam kehidupan sehari-hari sebagai petunjuk dari alam semesta.`
    } catch (error) {
      console.error("Error fetching AI prediction:", error)

      return `Berdasarkan ${type.toLowerCase()} "${input}", angka ${result} muncul sebagai simbol penting. 

Angka ini membawa energi kebijaksanaan dan transformasi dalam tradisi spiritual. 

Perhatikan kemunculannya dalam kehidupan sehari-hari sebagai petunjuk dari alam semesta.`
    }
  }

  const onPredict = async (values: z.infer<typeof predictionSchema>) => {
    if (!isLoggedIn) {
      setShowLoginDialog(true)
      return
    }

    setIsLoading(true)
    setIsGenerating(true)
    setGenerationProgress(0)
    setImageResult(null)

    setOutputType(values.outputType)

    const progressInterval = setInterval(() => {
      setGenerationProgress((prev) => {
        const newProgress = prev + Math.floor(Math.random() * 10) + 5
        return newProgress > 100 ? 100 : newProgress
      })
    }, 300)

    try {
      const randomResult = generateRandomNumberByType(values.outputType)
      const responseText = await generatePredictionResponse(
        values.predictionType,
        values.predictionInput,
        randomResult,
        values.outputType,
      )

      setResult(randomResult)
      setAiResponse(responseText)

      const newPrediction = {
        date: new Date().toLocaleDateString("id-ID", {
          day: "2-digit",
          month: "2-digit",
          year: "numeric",
          hour: "2-digit",
          minute: "2-digit",
        }),
        type: values.predictionType,
        input: values.predictionInput,
        result: randomResult,
        outputType: values.outputType,
      }

      const updatedHistory = [newPrediction, ...predictionHistory.slice(0, 9)]
      setPredictionHistory(updatedHistory)

      if (userData) {
        localStorage.setItem(`predictionHistory_${userData.phoneNumber}`, JSON.stringify(updatedHistory))
      }
    } catch (error) {
      console.error("Error in prediction process:", error)
    } finally {
      clearInterval(progressInterval)
      setGenerationProgress(100)
      setIsLoading(false)

      setTimeout(() => {
        setIsGenerating(false)
      }, 1000)
    }
  }

  const handleOutputTypeChange = (value: string) => {
    predictionForm.setValue("outputType", value)
    setOutputType(value)
  }

  return (
    <>
      <Card className="bg-gradient-to-br from-purple-800/50 via-indigo-800/50 to-purple-800/50 backdrop-blur-md border-purple-500/30 shadow-lg overflow-hidden">
        <CardHeader className="pb-2 bg-gradient-to-r from-purple-800/50 to-indigo-800/50 relative">
          <div className="absolute inset-0 bg-grid-white/5 opacity-10"></div>
          <div className="relative z-10 flex justify-between items-center">
            <div>
              <CardTitle className="text-white flex items-center">
                <Sparkles className="mr-2 h-5 w-5 text-yellow-400" />
                Ramalan Dewa Prediksi
              </CardTitle>
              <CardDescription className="text-white">
                Masukkan detail untuk mendapatkan angka keberuntungan ilahi
              </CardDescription>
            </div>
            {isLoggedIn && userData && (
              <div className="flex items-center gap-2">
                <Badge variant="outline" className="text-yellow-300 border-yellow-500/50 px-3 py-1">
                  <Phone className="h-3 w-3 mr-1" />
                  {userData.phoneNumber}
                </Badge>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={handleLogout}
                  className="text-white hover:text-white hover:bg-purple-800/50"
                >
                  Keluar
                </Button>
              </div>
            )}
          </div>
        </CardHeader>
        <CardContent className="p-0">
          {isLoggedIn ? (
            <Tabs defaultValue="prediction" className="w-full">
              <TabsList className="grid w-full grid-cols-2 bg-purple-900/50 rounded-none">
                <TabsTrigger
                  value="prediction"
                  className="data-[state=active]:bg-purple-800/50 rounded-none text-white"
                >
                  Buat Prediksi
                </TabsTrigger>
                <TabsTrigger value="history" className="data-[state=active]:bg-purple-800/50 rounded-none text-white">
                  Riwayat Prediksi
                </TabsTrigger>
              </TabsList>

              <TabsContent value="prediction" className="p-6">
                <Form {...predictionForm}>
                  <form onSubmit={predictionForm.handleSubmit(onPredict)} className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-6">
                      <FormField
                        control={predictionForm.control}
                        name="predictionType"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-white">Jenis Prediksi</FormLabel>
                            <Select onValueChange={field.onChange} defaultValue={field.value}>
                              <FormControl>
                                <SelectTrigger className="bg-white/20 border-purple-500/30 text-white">
                                  <SelectValue placeholder="Pilih jenis prediksi" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent className="bg-purple-900 border-purple-500/30 text-white">
                                {predictionTypes.map((type) => (
                                  <SelectItem key={type} value={type}>
                                    {type}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormMessage className="text-red-300" />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={predictionForm.control}
                        name="market"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-white">Pasaran Togel</FormLabel>
                            <Select onValueChange={field.onChange} defaultValue={field.value}>
                              <FormControl>
                                <SelectTrigger className="bg-white/20 border-purple-500/30 text-white">
                                  <SelectValue placeholder="Pilih pasaran togel" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent className="bg-purple-900 border-purple-500/30 text-white">
                                {markets.map((market) => (
                                  <SelectItem key={market} value={market}>
                                    {market}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormMessage className="text-red-300" />
                          </FormItem>
                        )}
                      />
                    </div>

                    <FormField
                      control={predictionForm.control}
                      name="predictionInput"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-white">Detail Prediksi</FormLabel>
                          <FormControl>
                            <Textarea
                              placeholder="Ceritakan detail lengkap untuk prediksi (mimpi, kejadian, dll.)"
                              className="bg-white/20 border-purple-500/30 text-white placeholder:text-white/70 min-h-[120px]"
                              {...field}
                            />
                          </FormControl>
                          <FormMessage className="text-red-300" />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={predictionForm.control}
                      name="outputType"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-white">Jenis Output Prediksi</FormLabel>
                          <FormControl>
                            <div className="bg-purple-900/50 p-2 rounded-lg border border-purple-500/30">
                              <ToggleGroup
                                type="single"
                                value={field.value}
                                onValueChange={(value) => {
                                  if (value) handleOutputTypeChange(value)
                                }}
                                className="flex flex-wrap justify-center gap-2"
                              >
                                <ToggleGroupItem
                                  value="2D"
                                  className="bg-purple-800/50 data-[state=on]:bg-gradient-to-r data-[state=on]:from-purple-600 data-[state=on]:to-indigo-600 text-white"
                                >
                                  2D
                                </ToggleGroupItem>
                                <ToggleGroupItem
                                  value="3D"
                                  className="bg-purple-800/50 data-[state=on]:bg-gradient-to-r data-[state=on]:from-purple-600 data-[state=on]:to-indigo-600 text-white"
                                >
                                  3D
                                </ToggleGroupItem>
                                <ToggleGroupItem
                                  value="4D"
                                  className="bg-purple-800/50 data-[state=on]:bg-gradient-to-r data-[state=on]:from-purple-600 data-[state=on]:to-indigo-600 text-white"
                                >
                                  4D
                                </ToggleGroupItem>
                                <ToggleGroupItem
                                  value="BBFS"
                                  className="bg-purple-800/50 data-[state=on]:bg-gradient-to-r data-[state=on]:from-purple-600 data-[state=on]:to-indigo-600 text-white"
                                >
                                  BBFS
                                </ToggleGroupItem>
                                <ToggleGroupItem
                                  value="Colok Bebas"
                                  className="bg-purple-800/50 data-[state=on]:bg-gradient-to-r data-[state=on]:from-purple-600 data-[state=on]:to-indigo-600 text-white"
                                >
                                  Colok Bebas
                                </ToggleGroupItem>
                                <ToggleGroupItem
                                  value="Colok Jitu"
                                  className="bg-purple-800/50 data-[state=on]:bg-gradient-to-r data-[state=on]:from-purple-600 data-[state=on]:to-indigo-600 text-white"
                                >
                                  Colok Jitu
                                </ToggleGroupItem>
                                <ToggleGroupItem
                                  value="Shio"
                                  className="bg-purple-800/50 data-[state=on]:bg-gradient-to-r data-[state=on]:from-purple-600 data-[state=on]:to-indigo-600 text-white"
                                >
                                  Shio
                                </ToggleGroupItem>
                              </ToggleGroup>
                            </div>
                          </FormControl>
                          <FormMessage className="text-red-300" />
                        </FormItem>
                      )}
                    />

                    <Button
                      type="submit"
                      className="w-full bg-gradient-to-r from-yellow-600 to-amber-600 hover:from-yellow-700 hover:to-amber-700 text-white border-none"
                      disabled={isLoading}
                    >
                      {isLoading ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          Memproses...
                        </>
                      ) : (
                        "Dapatkan Ramalan Ilahi"
                      )}
                    </Button>
                  </form>
                </Form>

                {isGenerating && (
                  <div className="mt-6 p-4 bg-purple-800/50 rounded-lg border border-purple-500/30">
                    <h3 className="text-xl font-bold text-white mb-2 flex items-center">
                      <Sparkles className="mr-2 h-5 w-5 text-yellow-400 animate-pulse" />
                      Sedang Menganalisis
                    </h3>
                    <div className="w-full bg-purple-900/70 rounded-full h-2.5 mb-2">
                      <div
                        className="h-2.5 rounded-full bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 animate-pulse"
                        style={{ width: `${generationProgress}%` }}
                      ></div>
                    </div>
                    <div className="text-white text-sm">
                      {generationProgress < 30
                        ? "Mengumpulkan data energi..."
                        : generationProgress < 60
                          ? "Menganalisis pola angka..."
                          : generationProgress < 90
                            ? "Menghitung resonansi..."
                            : "Finalisasi prediksi..."}
                    </div>
                  </div>
                )}

                <AnimatePresence>
                  {aiResponse && !isGenerating && (
                    <motion.div
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -20 }}
                      transition={{ duration: 0.5 }}
                      className="mt-6 p-6 bg-gradient-to-r from-purple-900/70 via-indigo-800/70 to-purple-900/70 rounded-lg border-2 border-purple-500/50 shadow-lg"
                    >
                      <h3 className="text-2xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-yellow-300 via-yellow-200 to-yellow-300 mb-4 flex items-center">
                        <Sparkles className="mr-2 h-6 w-6 text-yellow-300 animate-pulse" />
                        Analisis Prediksi Ilahi
                      </h3>
                      <div className="text-white whitespace-pre-line relative">
                        <div className="absolute -top-4 -left-4 w-12 h-12 text-yellow-500/30 animate-spin-slow">
                          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
                            <path d="M12 1L9 9H2L7 14.5L5 22L12 17.5L19 22L17 14.5L22 9H15L12 1Z" />
                          </svg>
                        </div>
                        <div className="absolute -bottom-4 -right-4 w-10 h-10 text-purple-500/30 animate-spin-slow-reverse">
                          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
                            <path d="M12 1L9 9H2L7 14.5L5 22L12 17.5L19 22L17 14.5L22 9H15L12 1Z" />
                          </svg>
                        </div>

                        <div className="relative z-10 text-lg leading-relaxed">{aiResponse}</div>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>

                <AnimatePresence>
                  {imageResult && !isGenerating && (
                    <motion.div
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -20 }}
                      transition={{ duration: 0.5 }}
                      className="mt-6 p-6 bg-gradient-to-r from-purple-900/70 via-indigo-800/70 to-purple-900/70 rounded-lg border-2 border-purple-500/50 shadow-lg flex flex-col items-center"
                    >
                      <h3 className="text-2xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-yellow-300 via-yellow-200 to-yellow-300 mb-4 flex items-center">
                        <Sparkles className="mr-2 h-6 w-6 text-yellow-300 animate-pulse" />
                        Visualisasi Ramalan Ilahi
                      </h3>
                      <div className="relative w-full max-w-md overflow-hidden rounded-lg border-2 border-yellow-500/50 shadow-xl">
                        <div className="absolute top-0 left-0 w-12 h-12 border-t-4 border-l-4 border-yellow-400/70 rounded-tl-lg"></div>
                        <div className="absolute top-0 right-0 w-12 h-12 border-t-4 border-r-4 border-yellow-400/70 rounded-tr-lg"></div>
                        <div className="absolute bottom-0 left-0 w-12 h-12 border-b-4 border-l-4 border-yellow-400/70 rounded-bl-lg"></div>
                        <div className="absolute bottom-0 right-0 w-12 h-12 border-b-4 border-r-4 border-yellow-400/70 rounded-br-lg"></div>

                        <img
                          src={imageResult || "/placeholder.svg"}
                          alt="Ramalan Ilahi"
                          className="w-full h-auto"
                          onLoad={() => {
                            const img = document.querySelector('img[alt="Ramalan Ilahi"]')
                            if (img) {
                              img.classList.add("animate-pulse")
                              setTimeout(() => img.classList.remove("animate-pulse"), 1000)
                            }
                          }}
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-purple-900/80 via-purple-800/40 to-transparent pointer-events-none"></div>

                        <div className="absolute top-4 left-4 w-8 h-8 text-yellow-500/40 animate-spin-slow">
                          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
                            <path d="M12 1L9 9H2L7 14.5L5 22L12 17.5L19 22L17 14.5L22 9H15L12 1Z" />
                          </svg>
                        </div>
                        <div className="absolute bottom-4 right-4 w-6 h-6 text-purple-500/40 animate-spin-slow-reverse">
                          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
                            <path d="M12 1L9 9H2L7 14.5L5 22L12 17.5L19 22L17 14.5L22 9H15L12 1Z" />
                          </svg>
                        </div>
                      </div>
                      <p className="text-yellow-300 text-lg mt-4 text-center italic font-medium">
                        "Gambar ini mengandung energi kosmik yang memperkuat prediksi Anda"
                      </p>
                    </motion.div>
                  )}
                </AnimatePresence>

                <AnimatePresence>
                  {result && !isGenerating && (
                    <motion.div
                      initial={{ opacity: 0, scale: 0.8 }}
                      animate={{ opacity: 1, scale: 1 }}
                      exit={{ opacity: 0, scale: 0.8 }}
                      transition={{ duration: 0.5, delay: 0.2 }}
                      className="mt-6 p-4 sm:p-8 bg-gradient-to-r from-purple-900/70 via-indigo-800/70 to-purple-900/70 rounded-lg border-2 border-purple-500/50 shadow-xl flex flex-col items-center relative overflow-hidden"
                    >
                      <div className="absolute inset-0 overflow-hidden">
                        <div className="absolute top-0 left-0 w-full h-full bg-grid-white/5 opacity-20"></div>
                        <div className="absolute -top-24 -left-24 w-48 h-48 bg-yellow-500/10 rounded-full blur-3xl"></div>
                        <div className="absolute -bottom-24 -right-24 w-48 h-48 bg-purple-500/10 rounded-full blur-3xl"></div>
                      </div>

                      {[...Array(12)].map((_, i) => (
                        <motion.div
                          key={i}
                          className="absolute w-2 h-2 rounded-full bg-yellow-500/30"
                          initial={{
                            x: Math.random() * 300 - 150,
                            y: Math.random() * 300 - 150,
                            opacity: 0,
                          }}
                          animate={{
                            x: Math.random() * 300 - 150,
                            y: Math.random() * 300 - 150,
                            opacity: [0, 0.8, 0],
                            scale: [0, 1, 0],
                          }}
                          transition={{
                            repeat: Number.POSITIVE_INFINITY,
                            duration: 3 + Math.random() * 5,
                            delay: Math.random() * 2,
                          }}
                        />
                      ))}

                      <h3 className="text-2xl sm:text-3xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-yellow-300 via-amber-200 to-yellow-300 mb-6 flex items-center relative z-10 text-center">
                        <Badge className="mr-2 sm:mr-3 bg-gradient-to-r from-yellow-600 to-amber-500 text-white px-2 sm:px-3 py-1 text-sm sm:text-lg">
                          {outputType}
                        </Badge>
                        Ramalan Dewa Prediksi
                      </h3>

                      <div className="relative z-10 mb-4">
                        <div className="absolute -inset-4 bg-gradient-to-r from-pink-500 via-purple-500 to-pink-500 rounded-lg blur opacity-75 animate-pulse"></div>
                        <div className="relative text-4xl sm:text-6xl font-bold text-yellow-300 tracking-widest bg-purple-900/90 px-6 sm:px-10 py-4 sm:py-6 rounded-lg border-2 border-yellow-500/50 shadow-[0_0_15px_rgba(234,179,8,0.3)]">
                          {result.split("").map((digit, index) => (
                            <motion.span
                              key={index}
                              initial={{ opacity: 0, y: -20 }}
                              animate={{ opacity: 1, y: 0 }}
                              transition={{ delay: 0.3 + index * 0.1, duration: 0.5 }}
                              className="inline-block mx-1"
                            >
                              {digit}
                            </motion.span>
                          ))}
                        </div>
                      </div>

                      <motion.div
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        transition={{ delay: 0.8, duration: 0.5 }}
                        className="text-white text-xl italic mt-4 text-center relative z-10"
                      >
                        Angka keberuntungan telah terpilih untuk Anda
                      </motion.div>

                      <div className="absolute top-6 left-6 text-yellow-500/30 w-12 h-12 animate-spin-slow">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
                          <path d="M12 1L9 9H2L7 14.5L5 22L12 17.5L19 22L17 14.5L22 9H15L12 1Z" />
                        </svg>
                      </div>
                      <div className="absolute bottom-6 right-6 text-purple-500/30 w-10 h-10 animate-spin-slow-reverse">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
                          <path d="M12 1L9 9H2L7 14.5L5 22L12 17.5L19 22L17 14.5L22 9H15L12 1Z" />
                        </svg>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </TabsContent>

              <TabsContent value="history" className="p-6">
                <div className="space-y-4">
                  <h3 className="text-xl font-bold text-white">Riwayat Prediksi Anda</h3>

                  {predictionHistory.length > 0 ? (
                    <div className="space-y-4">
                      {predictionHistory.map((item, index) => (
                        <motion.div
                          key={index}
                          initial={{ opacity: 0, y: 20 }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={{ duration: 0.3, delay: index * 0.05 }}
                          className="p-4 bg-gradient-to-r from-purple-800/40 to-indigo-800/40 rounded-lg border border-purple-500/30 hover:border-purple-400/50 transition-all duration-300"
                        >
                          <div className="flex justify-between items-center mb-2">
                            <span className="text-white text-sm">{item.date}</span>
                            <div className="flex gap-2">
                              <Badge className="bg-gradient-to-r from-purple-600 to-indigo-600 text-white">
                                {item.type}
                              </Badge>
                              <Badge className="bg-gradient-to-r from-yellow-600 to-yellow-500 text-white">
                                {item.outputType}
                              </Badge>
                            </div>
                          </div>
                          <p className="text-white mb-3 text-sm line-clamp-2">{item.input}</p>
                          <div className="flex justify-center">
                            <div className="text-2xl font-bold text-yellow-300 tracking-widest bg-purple-900/70 px-4 py-2 rounded-lg border border-purple-500/50">
                              {item.result}
                            </div>
                          </div>
                        </motion.div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center p-6 bg-purple-800/30 rounded-lg">
                      <p className="text-white">Anda belum memiliki riwayat prediksi</p>
                    </div>
                  )}
                </div>
              </TabsContent>
            </Tabs>
          ) : (
            <div className="text-center p-6">
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.5 }}
              >
                <AlertTriangle className="h-12 w-12 text-yellow-400 mx-auto mb-4" />
                <h3 className="text-xl font-bold text-white mb-2">Login Diperlukan</h3>
                <p className="text-white mb-4">Anda harus login terlebih dahulu untuk menggunakan fitur prediksi</p>
                <Button
                  onClick={() => setShowLoginDialog(true)}
                  className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white"
                >
                  Login / Daftar
                </Button>
              </motion.div>
            </div>
          )}
        </CardContent>
      </Card>

      <Dialog open={showLoginDialog} onOpenChange={setShowLoginDialog}>
        <DialogContent className="bg-gradient-to-br from-purple-900 to-indigo-900 border-purple-500/30 text-white sm:max-w-md p-0 overflow-hidden">
          <DialogHeader className="p-4 sm:p-6 pb-2 sm:pb-4 bg-gradient-to-r from-purple-800/50 to-indigo-800/50">
            <DialogTitle className="text-xl font-bold text-center">Login / Daftar</DialogTitle>
            <DialogDescription className="text-white text-center">
              Login atau daftar untuk menggunakan fitur prediksi
            </DialogDescription>
            <DialogClose className="absolute right-4 top-4 rounded-sm opacity-70 ring-offset-background transition-opacity hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:pointer-events-none data-[state=open]:bg-accent data-[state=open]:text-muted-foreground">
              <X className="h-4 w-4 text-white" />
              <span className="sr-only">Close</span>
            </DialogClose>
          </DialogHeader>

          <Tabs defaultValue="login" className="w-full">
            <div className="px-4 sm:px-6 pt-4">
              <TabsList className="grid w-full grid-cols-2 bg-purple-800/50 mb-6 p-1 rounded-md">
                <TabsTrigger
                  value="login"
                  className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-purple-700 data-[state=active]:to-indigo-700 text-white py-3 rounded-md"
                >
                  Login
                </TabsTrigger>
                <TabsTrigger
                  value="register"
                  className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-purple-700 data-[state=active]:to-indigo-700 text-white py-3 rounded-md"
                >
                  Daftar
                </TabsTrigger>
              </TabsList>
            </div>

            <TabsContent value="login" className="px-4 sm:px-6 pb-6">
              <Form {...loginForm}>
                <form onSubmit={loginForm.handleSubmit(onLogin)} className="space-y-5">
                  <FormField
                    control={loginForm.control}
                    name="phoneNumber"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-white text-sm font-medium">Nomor HP</FormLabel>
                        <FormControl>
                          <div className="relative">
                            <Phone className="absolute left-3 top-3 h-4 w-4 text-white" />
                            <Input
                              placeholder="08xxxxxxxxx"
                              className="bg-white/20 border-purple-500/30 pl-10 text-white h-12 rounded-md"
                              {...field}
                            />
                          </div>
                        </FormControl>
                        <FormMessage className="text-red-300" />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={loginForm.control}
                    name="password"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-white text-sm font-medium">Password</FormLabel>
                        <FormControl>
                          <div className="relative">
                            <Lock className="absolute left-3 top-3 h-4 w-4 text-white" />
                            <Input
                              type={showPassword ? "text" : "password"}
                              className="bg-white/20 border-purple-500/30 pl-10 pr-10 text-white h-12 rounded-md"
                              {...field}
                            />
                            <button
                              type="button"
                              className="absolute right-3 top-3 text-white"
                              onClick={() => setShowPassword(!showPassword)}
                            >
                              {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                            </button>
                          </div>
                        </FormControl>
                        <FormMessage className="text-red-300" />
                      </FormItem>
                    )}
                  />

                  <Button
                    type="submit"
                    className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white h-12 rounded-md font-medium"
                    disabled={isLoading}
                  >
                    {isLoading ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Memproses...
                      </>
                    ) : (
                      "Login"
                    )}
                  </Button>
                </form>
              </Form>
            </TabsContent>

            <TabsContent value="register" className="px-4 sm:px-6 pb-6">
              <Form {...registrationForm}>
                <form onSubmit={registrationForm.handleSubmit(onRegister)} className="space-y-4">
                  <FormField
                    control={registrationForm.control}
                    name="phoneNumber"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-white">Nomor HP</FormLabel>
                        <FormControl>
                          <div className="relative">
                            <Phone className="absolute left-3 top-3 h-4 w-4 text-white" />
                            <Input
                              placeholder="08xxxxxxxxx"
                              className="bg-white/20 border-purple-500/30 pl-10 text-white h-12"
                              {...field}
                              onBlur={(e) => {
                                field.onBlur()
                                startWhatsAppVerification(e.target.value)
                              }}
                            />
                          </div>
                        </FormControl>
                        <FormMessage className="text-red-300" />
                      </FormItem>
                    )}
                  />

                  {phoneToVerify && (
                    <WhatsAppVerification
                      phoneNumber={phoneToVerify}
                      onVerificationComplete={handlePhoneVerification}
                    />
                  )}

                  <FormField
                    control={registrationForm.control}
                    name="fullName"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-white">Nama Lengkap</FormLabel>
                        <FormControl>
                          <Input
                            placeholder="Nama lengkap Anda"
                            className="bg-white/20 border-purple-500/30 text-white h-12"
                            {...field}
                          />
                        </FormControl>
                        <FormMessage className="text-red-300" />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={registrationForm.control}
                    name="password"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-white">Password</FormLabel>
                        <FormControl>
                          <div className="relative">
                            <Lock className="absolute left-3 top-3 h-4 w-4 text-white" />
                            <Input
                              type={showPassword ? "text" : "password"}
                              className="bg-white/20 border-purple-500/30 pl-10 pr-10 text-white h-12"
                              {...field}
                            />
                            <button
                              type="button"
                              className="absolute right-3 top-3 text-white"
                              onClick={() => setShowPassword(!showPassword)}
                            >
                              {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                            </button>
                          </div>
                        </FormControl>
                        <FormMessage className="text-red-300" />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={registrationForm.control}
                    name="agreeTerms"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                        <FormControl>
                          <Checkbox
                            checked={field.value}
                            onCheckedChange={field.onChange}
                            className="data-[state=checked]:bg-purple-600 data-[state=checked]:border-purple-600"
                          />
                        </FormControl>
                        <div className="space-y-1 leading-none">
                          <FormLabel className="text-sm font-normal text-white">
                            Saya menyetujui syarat dan ketentuan yang berlaku
                          </FormLabel>
                          <FormMessage className="text-red-300" />
                        </div>
                      </FormItem>
                    )}
                  />

                  <Button
                    type="submit"
                    className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white h-12"
                    disabled={isLoading}
                  >
                    {isLoading ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Memproses...
                      </>
                    ) : (
                      "Daftar"
                    )}
                  </Button>
                </form>
              </Form>
            </TabsContent>
          </Tabs>
        </DialogContent>
      </Dialog>
    </>
  )
}
