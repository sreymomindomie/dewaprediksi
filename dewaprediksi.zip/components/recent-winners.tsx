"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { motion, AnimatePresence } from "framer-motion"
import { Trophy, Sparkles } from "lucide-react"

type Winner = {
  name: string
  phoneNumber: string
  amount: string
  market: string
  time: string
  predictionType: string
  predictionInput: string
  outputType: string
}

export function DewaPrediksi() {
  const [winners, setWinners] = useState<Winner[]>([])

  // Generate pemenang dari prediksi
  useEffect(() => {
    const names = [
      "Budi S.",
      "Siti R.",
      "Ahmad D.",
      "Dewi L.",
      "Joko W.",
      "Rina P.",
      "Agus H.",
      "Lina K.",
      "Dedi S.",
      "Maya T.",
    ]

    const markets = ["Hongkong", "Singapore", "Sydney", "Macau", "Taiwan"]

    const predictionTypes = ["Mimpi", "Kejadian Sehari-hari", "Tanggal Lahir", "Plat Nomor", "Nama"]

    const outputTypes = ["2D", "3D", "4D", "BBFS", "Colok Bebas", "Colok Jitu", "Shio"]

    const predictionInputs = [
      "Mimpi dikejar ular besar",
      "Bertemu kucing hitam di jalan",
      "Tanggal lahir anak saya 12-05-2020",
      "Plat nomor mobil baru B 1234 CD",
      "Nama anak yang baru lahir",
      "Melihat angka 2795 berulang kali",
      "Mimpi hujan deras dan banjir",
      "Bertemu dengan teman lama",
      "Melihat pelangi kembar",
    ]

    const generatePhoneNumber = () => {
      const prefix = "08"
      const number = Math.floor(Math.random() * 1000000000)
        .toString()
        .padStart(9, "0")
      return `${prefix}${number.substring(0, 3)}****${number.substring(7)}`
    }

    const generateAmount = () => {
      const amounts = [
        "Rp 5.000.000",
        "Rp 10.000.000",
        "Rp 25.000.000",
        "Rp 50.000.000",
        "Rp 100.000.000",
        "Rp 250.000.000",
      ]
      return amounts[Math.floor(Math.random() * amounts.length)]
    }

    const generateTime = () => {
      const hours = Math.floor(Math.random() * 24)
        .toString()
        .padStart(2, "0")
      const minutes = Math.floor(Math.random() * 60)
        .toString()
        .padStart(2, "0")
      return `${hours}:${minutes}`
    }

    const initialWinners: Winner[] = []
    for (let i = 0; i < 8; i++) {
      initialWinners.push({
        name: names[Math.floor(Math.random() * names.length)],
        phoneNumber: generatePhoneNumber(),
        amount: generateAmount(),
        market: markets[Math.floor(Math.random() * markets.length)],
        time: generateTime(),
        predictionType: predictionTypes[Math.floor(Math.random() * predictionTypes.length)],
        predictionInput: predictionInputs[Math.floor(Math.random() * predictionTypes.length)],
        outputType: outputTypes[Math.floor(Math.random() * outputTypes.length)],
      })
    }

    setWinners(initialWinners)

    // Add new winner every 10 seconds
    const interval = setInterval(() => {
      const newWinner = {
        name: names[Math.floor(Math.random() * names.length)],
        phoneNumber: generatePhoneNumber(),
        amount: generateAmount(),
        market: markets[Math.floor(Math.random() * markets.length)],
        time: generateTime(),
        predictionType: predictionTypes[Math.floor(Math.random() * predictionTypes.length)],
        predictionInput: predictionInputs[Math.floor(Math.random() * predictionTypes.length)],
        outputType: outputTypes[Math.floor(Math.random() * outputTypes.length)],
      }

      setWinners((prev) => [newWinner, ...prev.slice(0, 7)])
    }, 10000)

    return () => clearInterval(interval)
  }, [])

  return (
    <Card className="bg-gradient-to-br from-purple-800/50 via-indigo-800/50 to-purple-800/50 border-purple-500/30 shadow-lg overflow-hidden">
      <CardHeader className="pb-2 bg-gradient-to-r from-purple-800/50 to-indigo-800/50">
        <CardTitle className="text-white text-xl flex items-center">
          <Trophy className="mr-2 h-5 w-5 text-yellow-400" />
          Dewa Prediksi
        </CardTitle>
      </CardHeader>
      <CardContent className="p-4">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
          <AnimatePresence initial={false}>
            {winners.map((winner, index) => (
              <motion.div
                key={`${winner.name}-${winner.time}-${index}`}
                initial={{ opacity: 0, x: -100 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 100 }}
                transition={{ duration: 0.5 }}
                className="bg-gradient-to-r from-purple-800/40 to-indigo-800/40 rounded-lg border border-purple-500/30 p-3 sm:p-4 hover:border-purple-400/50 transition-all duration-300"
              >
                <div className="flex justify-between items-center mb-2">
                  <div className="flex items-center">
                    <div className="w-2 h-2 bg-green-400 rounded-full mr-2 animate-pulse"></div>
                    <div className="font-medium text-white text-sm sm:text-base">{winner.name}</div>
                  </div>
                  <Badge className="bg-gradient-to-r from-yellow-600 to-yellow-500 text-white text-xs">
                    {winner.outputType}
                  </Badge>
                </div>
                <div className="text-xs text-white mb-2">{winner.phoneNumber}</div>
                <div className="bg-purple-900/40 p-2 rounded-md mb-2">
                  <div className="flex items-center text-xs text-white mb-1">
                    <Sparkles className="h-3 w-3 mr-1 text-yellow-400" />
                    <span>Prediksi: {winner.predictionType}</span>
                  </div>
                  <div className="text-xs text-white line-clamp-1">{winner.predictionInput}</div>
                </div>
                <div className="flex justify-between items-center">
                  <Badge variant="outline" className="text-xs border-purple-500/30 text-white">
                    {winner.market}
                  </Badge>
                  <div className="font-bold text-yellow-300 text-sm sm:text-base">{winner.amount}</div>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      </CardContent>
    </Card>
  )
}
