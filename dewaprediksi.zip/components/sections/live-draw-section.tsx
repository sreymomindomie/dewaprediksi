"use client"

import { useState, useEffect, useRef } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { LiveDraw } from "@/components/live-draw"
import { motion } from "framer-motion"

export function LiveDrawSection() {
  const [activeMarket, setActiveMarket] = useState("hongkong")
  const [currentTime, setCurrentTime] = useState(new Date())
  const tabsListRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date())
    }, 1000)

    return () => clearInterval(timer)
  }, [])

  // Scroll active tab into view when it changes
  useEffect(() => {
    if (tabsListRef.current) {
      const activeTabElement = tabsListRef.current.querySelector('[data-state="active"]')
      if (activeTabElement) {
        const tabsListRect = tabsListRef.current.getBoundingClientRect()
        const activeTabRect = activeTabElement.getBoundingClientRect()

        // Calculate the scroll position to center the active tab
        const scrollLeft = activeTabRect.left - tabsListRect.left - tabsListRect.width / 2 + activeTabRect.width / 2

        tabsListRef.current.scrollTo({
          left: scrollLeft,
          behavior: "smooth",
        })
      }
    }
  }, [activeMarket])

  // Define markets with proper time format
  const markets = [
    { id: "hongkong", name: "Hongkong", time: "23:00" },
    { id: "singapore", name: "Singapore", time: "17:45" },
    { id: "sydney", name: "Sydney", time: "13:50" },
    { id: "macau", name: "Macau", time: "15:30" },
    { id: "taiwan", name: "Taiwan", time: "20:00" },
  ]

  return (
    <Card className="bg-gradient-to-br from-purple-800/50 via-indigo-800/50 to-purple-800/50 backdrop-blur-md border-purple-500/30 shadow-lg">
      <CardContent className="p-0">
        <div className="flex items-center justify-between p-3 sm:p-4 bg-gradient-to-r from-purple-800/50 to-indigo-800/50">
          <h2 className="text-lg sm:text-xl font-bold text-white flex items-center">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              className="h-4 w-4 sm:h-5 sm:w-5 mr-1 sm:mr-2"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z"
              />
            </svg>
            Live Draw Togel
          </h2>
          <div className="text-white text-xs sm:text-sm">
            {currentTime.toLocaleTimeString("id-ID", {
              hour: "2-digit",
              minute: "2-digit",
              second: "2-digit",
            })}
          </div>
        </div>

        <Tabs defaultValue="hongkong" className="w-full" onValueChange={setActiveMarket}>
          <div className="tabs-list-container overflow-x-auto" ref={tabsListRef}>
            <TabsList className="h-12 sm:h-14 flex w-full bg-gradient-to-r from-purple-900/70 to-indigo-900/70 p-1 rounded-none">
              {markets.map((market) => (
                <TabsTrigger
                  key={market.id}
                  value={market.id}
                  className={`relative z-10 flex-1 flex items-center justify-center py-1 sm:py-2 px-3 sm:px-6 transition-all duration-300 text-sm sm:text-base font-medium min-w-[80px] sm:min-w-[120px] ${
                    activeMarket === market.id
                      ? "text-white data-[state=active]:bg-transparent"
                      : "text-white/80 hover:text-white"
                  }`}
                >
                  {market.name}
                  {activeMarket === market.id && (
                    <motion.div
                      layoutId="activeMarketIndicator"
                      className="absolute inset-0 bg-gradient-to-r from-purple-600/80 via-indigo-600/80 to-purple-600/80 rounded-lg"
                      style={{ zIndex: -1 }}
                      transition={{ type: "spring", duration: 0.5 }}
                    />
                  )}
                </TabsTrigger>
              ))}
            </TabsList>
          </div>

          {markets.map((market) => (
            <TabsContent key={market.id} value={market.id} className="p-3 sm:p-4">
              <LiveDraw market={market.name} drawTime={market.time} />
            </TabsContent>
          ))}
        </Tabs>
      </CardContent>
    </Card>
  )
}
