"use client"

import { useState } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { AlertTriangle, Flame, TrendingUp } from "lucide-react"
import { motion } from "framer-motion"

type BocorData = {
  market: string
  date: string
  status: "Bocor" | "Hot" | "Normal"
  percentage: number
  angkaBocor: string
  angkaMatiBocor: string
  angkaIkut: string
  colokJitu: string
  notes: string
}

export function BocorSection() {
  const [bocorData] = useState<BocorData[]>([
    {
      market: "Hongkong",
      date: "18 Mei 2025",
      status: "Bocor",
      percentage: 92,
      angkaBocor: "2795",
      angkaMatiBocor: "1, 3, 4, 6, 8, 0",
      angkaIkut: "2, 7, 9, 5",
      colokJitu: "2 & 9",
      notes: "Pasaran Hongkong sedang bocor besar! Peluang menang sangat tinggi dengan angka-angka di atas.",
    },
    {
      market: "Singapore",
      date: "18 Mei 2025",
      status: "Hot",
      percentage: 78,
      angkaBocor: "3816",
      angkaMatiBocor: "0, 2, 4, 5, 7, 9",
      angkaIkut: "3, 8, 1, 6",
      colokJitu: "3 & 6",
      notes: "Pasaran Singapore sedang hot! Perhatikan angka-angka di atas untuk peluang menang yang lebih baik.",
    },
    {
      market: "Sydney",
      date: "18 Mei 2025",
      status: "Bocor",
      percentage: 88,
      angkaBocor: "4092",
      angkaMatiBocor: "1, 3, 5, 6, 7, 8",
      angkaIkut: "4, 0, 9, 2",
      colokJitu: "4 & 2",
      notes: "Pasaran Sydney sedang bocor! Gunakan angka-angka di atas untuk meningkatkan peluang kemenangan Anda.",
    },
    {
      market: "Macau",
      date: "18 Mei 2025",
      status: "Normal",
      percentage: 65,
      angkaBocor: "6371",
      angkaMatiBocor: "0, 2, 4, 5, 8, 9",
      angkaIkut: "6, 3, 7, 1",
      colokJitu: "6 & 1",
      notes: "Pasaran Macau dalam kondisi normal. Tetap perhatikan angka-angka di atas untuk panduan.",
    },
    {
      market: "Taiwan",
      date: "18 Mei 2025",
      status: "Hot",
      percentage: 82,
      angkaBocor: "5284",
      angkaMatiBocor: "0, 1, 3, 6, 7, 9",
      angkaIkut: "5, 2, 8, 4",
      colokJitu: "5 & 4",
      notes: "Pasaran Taiwan sedang hot! Perhatikan angka-angka di atas untuk peluang menang yang lebih baik.",
    },
  ])

  return (
    <div className="container mx-auto px-4">
      <div className="flex items-center mb-6">
        <div className="w-1.5 h-8 bg-gradient-to-b from-green-400 to-green-600 rounded-full mr-3"></div>
        <h2 className="text-2xl font-bold text-white">Bocoran Togel Hari Ini</h2>
      </div>

      <Tabs defaultValue="hongkong" className="w-full">
        <div className="mb-6 overflow-x-auto">
          <TabsList className="inline-flex h-auto items-center justify-center rounded-lg bg-gradient-to-r from-purple-900/70 to-indigo-900/70 p-1 text-white w-full overflow-x-auto">
            {bocorData.map((data) => (
              <TabsTrigger
                key={data.market}
                value={data.market.toLowerCase()}
                className="inline-flex items-center justify-center whitespace-nowrap rounded-md px-3 sm:px-6 py-2 sm:py-3 text-sm sm:text-base font-medium ring-offset-background transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 data-[state=active]:bg-gradient-to-r data-[state=active]:from-purple-700 data-[state=active]:to-indigo-700 data-[state=active]:text-white data-[state=active]:shadow-sm h-10 sm:h-12 text-white"
              >
                {data.market}
              </TabsTrigger>
            ))}
          </TabsList>
        </div>

        {bocorData.map((data) => (
          <TabsContent key={data.market} value={data.market.toLowerCase()}>
            <Card className="bg-gradient-to-br from-purple-800/50 via-indigo-800/50 to-purple-800/50 border-purple-500/30 shadow-lg overflow-hidden">
              <CardHeader className="pb-2 bg-gradient-to-r from-purple-800/50 to-indigo-800/50">
                <div className="flex justify-between items-center">
                  <CardTitle className="text-white text-2xl">Bocoran {data.market}</CardTitle>
                  <div className="flex items-center gap-2">
                    <StatusBadge status={data.status} />
                    <Badge className="bg-purple-700 py-1.5 px-3 text-sm text-white">{data.date}</Badge>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="p-4 sm:p-6">
                <div className="mb-4 sm:mb-6 p-3 sm:p-5 bg-gradient-to-r from-purple-800/50 to-indigo-800/50 rounded-lg border border-purple-600/30">
                  <div className="flex items-center justify-between mb-2 sm:mb-3">
                    <h3 className="text-lg sm:text-xl font-medium text-white flex items-center">
                      <TrendingUp className="h-4 w-4 sm:h-5 sm:w-5 mr-2 text-yellow-400" />
                      Status RTP
                    </h3>
                    <span className="text-lg sm:text-xl font-bold text-yellow-300">{data.percentage}%</span>
                  </div>
                  <div className="w-full bg-purple-900/70 rounded-full h-3 sm:h-4 overflow-hidden">
                    <motion.div
                      className={`h-full rounded-full ${
                        data.status === "Bocor"
                          ? "bg-gradient-to-r from-green-500 to-green-400"
                          : data.status === "Hot"
                            ? "bg-gradient-to-r from-yellow-500 to-yellow-400"
                            : "bg-gradient-to-r from-blue-500 to-blue-400"
                      }`}
                      initial={{ width: 0 }}
                      animate={{ width: `${data.percentage}%` }}
                      transition={{ duration: 1, ease: "easeOut" }}
                    ></motion.div>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 sm:gap-6">
                  <div className="space-y-6">
                    <div className="bg-gradient-to-r from-purple-800/50 to-indigo-800/50 rounded-lg p-5 border border-purple-600/30">
                      <h3 className="text-xl font-medium text-white mb-4">Angka Bocor</h3>
                      <div className="flex justify-center">
                        <div className="text-4xl font-bold text-yellow-300 tracking-widest bg-purple-900/70 px-8 py-4 rounded-lg border-2 border-yellow-500/50 shadow-lg">
                          {data.angkaBocor}
                        </div>
                      </div>
                    </div>

                    <div className="bg-gradient-to-r from-purple-800/50 to-indigo-800/50 rounded-lg p-5 border border-purple-600/30">
                      <h3 className="text-xl font-medium text-white mb-4">Colok Jitu</h3>
                      <div className="text-center text-2xl font-bold text-white">{data.colokJitu}</div>
                    </div>
                  </div>

                  <div className="space-y-6">
                    <div className="bg-gradient-to-r from-purple-800/50 to-indigo-800/50 rounded-lg p-5 border border-purple-600/30">
                      <h3 className="text-xl font-medium text-white mb-4">Angka Mati Bocor</h3>
                      <div className="text-center text-xl font-bold text-white">{data.angkaMatiBocor}</div>
                    </div>

                    <div className="bg-gradient-to-r from-purple-800/50 to-indigo-800/50 rounded-lg p-5 border border-purple-600/30">
                      <h3 className="text-xl font-medium text-white mb-4">Angka Ikut</h3>
                      <div className="text-center text-xl font-bold text-white">{data.angkaIkut}</div>
                    </div>
                  </div>
                </div>

                <div className="mt-6 p-5 bg-gradient-to-r from-purple-800/50 to-indigo-800/50 rounded-lg border border-purple-600/30">
                  <div className="flex items-center mb-3">
                    <AlertTriangle className="h-5 w-5 mr-2 text-yellow-400" />
                    <h3 className="text-xl font-medium text-white">Catatan Khusus</h3>
                  </div>
                  <p className="text-white text-lg">{data.notes}</p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        ))}
      </Tabs>
    </div>
  )
}

function StatusBadge({ status }: { status: "Bocor" | "Hot" | "Normal" }) {
  if (status === "Bocor") {
    return (
      <Badge className="bg-gradient-to-r from-green-600 to-green-500 hover:from-green-700 hover:to-green-600 py-1.5 px-3 text-sm flex items-center gap-1 animate-pulse text-white font-medium">
        <Flame className="h-4 w-4" />
        BOCOR
      </Badge>
    )
  }

  if (status === "Hot") {
    return (
      <Badge className="bg-gradient-to-r from-yellow-600 to-yellow-500 hover:from-yellow-700 hover:to-yellow-600 py-1.5 px-3 text-sm flex items-center gap-1 text-white font-medium">
        <Flame className="h-4 w-4" />
        HOT
      </Badge>
    )
  }

  return (
    <Badge className="bg-gradient-to-r from-blue-600 to-blue-500 hover:from-blue-700 hover:to-blue-600 py-1.5 px-3 text-sm flex items-center gap-1 text-white font-medium">
      <Flame className="h-4 w-4" />
      NORMAL
    </Badge>
  )
}
