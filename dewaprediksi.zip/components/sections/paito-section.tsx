"use client"

import { useState } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type PaitoData = {
  market: string
  months: string[]
  data: Record<string, string[][]>
}

export function PaitoSection() {
  const [selectedYear, setSelectedYear] = useState("2025")

  const [paitoData] = useState<PaitoData[]>([
    {
      market: "Hongkong",
      months: ["Januari", "Februari", "Maret", "April", "Mei"],
      data: {
        "2025": [
          // Januari
          [
            "8741",
            "3905",
            "7268",
            "1493",
            "5027",
            "9631",
            "4158",
            "2876",
            "6340",
            "7912",
            "5684",
            "0239",
            "8517",
            "3460",
            "9182",
            "6753",
            "2098",
            "7614",
            "3845",
            "9201",
            "5736",
            "1482",
            "8067",
            "4329",
            "6895",
            "2170",
            "7543",
            "0918",
            "4652",
            "1307",
            "8594",
          ],
          // Februari
          [
            "2761",
            "9043",
            "5128",
            "7694",
            "3810",
            "6457",
            "0932",
            "8516",
            "4270",
            "1685",
            "9324",
            "5807",
            "2143",
            "7698",
            "3452",
            "0916",
            "6583",
            "4271",
            "8709",
            "5346",
            "1890",
            "7625",
            "3048",
            "9471",
            "6235",
            "0897",
            "4512",
            "8760",
          ],
          // Maret
          [
            "3692",
            "7104",
            "2387",
            "9426",
            "5810",
            "1743",
            "8259",
            "4671",
            "0935",
            "6482",
            "3017",
            "9564",
            "7328",
            "1890",
            "5246",
            "8703",
            "4159",
            "0872",
            "6534",
            "2917",
            "8460",
            "5123",
            "1798",
            "7345",
            "9682",
            "4017",
            "0563",
            "6829",
            "3471",
            "8905",
            "2640",
          ],
          // April
          [
            "7513",
            "2896",
            "4072",
            "9651",
            "3248",
            "8705",
            "1439",
            "6082",
            "5917",
            "0364",
            "7821",
            "4596",
            "9130",
            "2857",
            "6493",
            "1728",
            "8305",
            "4962",
            "0187",
            "5643",
            "9270",
            "3816",
            "7459",
            "2083",
            "6541",
            "1907",
            "8364",
            "4520",
            "9178",
            "3645",
          ],
          // Mei
          [
            "5104",
            "9782",
            "3617",
            "8045",
            "2391",
            "7856",
            "4230",
            "9671",
            "1508",
            "6342",
            "0987",
            "5264",
            "3719",
            "8456",
            "2093",
            "7618",
            "4305",
          ],
        ],
        "2024": [
          // Januari (dummy data for 2024)
          [
            "1234",
            "5678",
            "9012",
            "3456",
            "7890",
            "2345",
            "6789",
            "0123",
            "4567",
            "8901",
            "2345",
            "6789",
            "0123",
            "4567",
            "8901",
            "2345",
            "6789",
            "0123",
            "4567",
            "8901",
            "2345",
            "6789",
            "0123",
            "4567",
            "8901",
            "2345",
            "6789",
            "0123",
            "4567",
            "8901",
            "2345",
          ],
          // More months would follow...
          [],
          [],
          [],
          [],
        ],
      },
    },
    {
      market: "Singapore",
      months: ["Januari", "Februari", "Maret", "April", "Mei"],
      data: {
        "2025": [
          // Januari
          [
            "7158",
            "2876",
            "6340",
            "9631",
            "4158",
            "8741",
            "3905",
            "7268",
            "1493",
            "5027",
            "0239",
            "8517",
            "3460",
            "9182",
            "6753",
            "2098",
            "7614",
            "3845",
            "9201",
            "5736",
            "1482",
            "8067",
            "4329",
            "6895",
            "2170",
            "7543",
            "0918",
            "4652",
            "1307",
            "8594",
            "5261",
          ],
          // More months...
          [],
          [],
          [],
          [],
        ],
        "2024": [
          // Dummy data
          [],
          [],
          [],
          [],
          [],
        ],
      },
    },
    {
      market: "Sydney",
      months: ["Januari", "Februari", "Maret", "April", "Mei"],
      data: {
        "2025": [
          // Januari
          [
            "3905",
            "7268",
            "1493",
            "5027",
            "9631",
            "4158",
            "8741",
            "2876",
            "6340",
            "7912",
            "5684",
            "0239",
            "8517",
            "3460",
            "9182",
            "6753",
            "2098",
            "7614",
            "3845",
            "9201",
            "5736",
            "1482",
            "8067",
            "4329",
            "6895",
            "2170",
            "7543",
            "0918",
            "4652",
            "1307",
            "8594",
          ],
          // More months...
          [],
          [],
          [],
          [],
        ],
        "2024": [
          // Dummy data
          [],
          [],
          [],
          [],
          [],
        ],
      },
    },
    // Add more markets as needed
  ])

  // Generate color for each digit
  const getDigitColor = (digit: string) => {
    const colors = [
      "bg-red-500", // 0
      "bg-green-500", // 1
      "bg-blue-500", // 2
      "bg-yellow-500", // 3
      "bg-purple-500", // 4
      "bg-pink-500", // 5
      "bg-indigo-500", // 6
      "bg-orange-500", // 7
      "bg-teal-500", // 8
      "bg-cyan-500", // 9
    ]
    return colors[Number.parseInt(digit)]
  }

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold text-white">Paito Warna</h2>
        <Select value={selectedYear} onValueChange={setSelectedYear}>
          <SelectTrigger className="w-[180px] bg-purple-800/50 border-purple-500/30 text-white">
            <SelectValue placeholder="Pilih Tahun" />
          </SelectTrigger>
          <SelectContent className="bg-purple-900 border-purple-500/30 text-white">
            <SelectItem value="2025">2025</SelectItem>
            <SelectItem value="2024">2024</SelectItem>
            <SelectItem value="2023">2023</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <Tabs defaultValue="hongkong" className="w-full">
        <TabsList className="grid w-full grid-cols-3 bg-purple-900/50 mb-6">
          {paitoData.map((data) => (
            <TabsTrigger
              key={data.market}
              value={data.market.toLowerCase()}
              className="data-[state=active]:bg-purple-800"
            >
              {data.market}
            </TabsTrigger>
          ))}
        </TabsList>

        {paitoData.map((data) => (
          <TabsContent key={data.market} value={data.market.toLowerCase()}>
            <Card className="bg-white/10 backdrop-blur-md border-purple-500/20">
              <CardHeader>
                <CardTitle className="text-white">
                  Paito Warna {data.market} - {selectedYear}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto -mx-4 sm:mx-0">
                  <div className="inline-block min-w-full align-middle px-4 sm:px-0">
                    <table className="min-w-full border-collapse">
                      <thead>
                        <tr>
                          <th className="border border-purple-700 bg-purple-800/70 text-white p-2 sticky left-0 z-10">
                            Tanggal
                          </th>
                          {Array.from({ length: 31 }, (_, i) => i + 1).map((day) => (
                            <th
                              key={day}
                              className="border border-purple-700 bg-purple-800/70 text-white p-2 text-center min-w-[40px]"
                            >
                              {day}
                            </th>
                          ))}
                        </tr>
                      </thead>
                      <tbody>
                        {data.months.map((month, monthIndex) => (
                          <tr key={month}>
                            <td className="border border-purple-700 bg-purple-800/50 text-white p-2 font-medium sticky left-0 z-10">
                              {month}
                            </td>
                            {Array.from({ length: 31 }, (_, i) => i).map((day) => {
                              const result = data.data[selectedYear]?.[monthIndex]?.[day] || "-"
                              return (
                                <td key={day} className="border border-purple-700 bg-purple-900/30 p-1 text-center">
                                  {result !== "-" ? (
                                    <div className="flex justify-center">
                                      {result.split("").map((digit, i) => (
                                        <span
                                          key={i}
                                          className={`inline-block w-4 h-4 sm:w-5 sm:h-5 text-xs font-bold text-white flex items-center justify-center ${getDigitColor(
                                            digit,
                                          )}`}
                                        >
                                          {digit}
                                        </span>
                                      ))}
                                    </div>
                                  ) : (
                                    <span className="text-gray-500">-</span>
                                  )}
                                </td>
                              )
                            })}
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        ))}
      </Tabs>
    </div>
  )
}
