"use client"

import { useState } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { ExternalLink, Info } from "lucide-react"

type PoolData = {
  name: string
  website: string
  schedule: string
  timezone: string
  description: string
  results: Array<{
    date: string
    numbers: string[]
    prizes: Record<string, string>
  }>
}

export function PoolsSection() {
  const [poolsData] = useState<PoolData[]>([
    {
      name: "Hongkong Pools",
      website: "hongkongpools.com",
      schedule: "Setiap hari: 23:00 WIB",
      timezone: "GMT+8",
      description:
        "Hongkong Pools adalah salah satu pasaran togel terpopuler di Asia. Hasil keluaran resmi diumumkan setiap hari pukul 23:00 WIB.",
      results: [
        {
          date: "17/05/2025",
          numbers: ["8", "7", "4", "1"],
          prizes: {
            "1st Prize": "Rp 100.000.000",
            "2nd Prize": "Rp 50.000.000",
            "3rd Prize": "Rp 25.000.000",
            Consolation: "Rp 5.000.000",
          },
        },
        {
          date: "16/05/2025",
          numbers: ["3", "9", "0", "5"],
          prizes: {
            "1st Prize": "Rp 100.000.000",
            "2nd Prize": "Rp 50.000.000",
            "3rd Prize": "Rp 25.000.000",
            Consolation: "Rp 5.000.000",
          },
        },
        {
          date: "15/05/2025",
          numbers: ["7", "2", "6", "8"],
          prizes: {
            "1st Prize": "Rp 100.000.000",
            "2nd Prize": "Rp 50.000.000",
            "3rd Prize": "Rp 25.000.000",
            Consolation: "Rp 5.000.000",
          },
        },
      ],
    },
    {
      name: "Singapore Pools",
      website: "singaporepools.com",
      schedule: "Senin, Kamis, Sabtu: 17:45 WIB",
      timezone: "GMT+8",
      description:
        "Singapore Pools adalah pasaran togel resmi dari Singapura. Hasil keluaran resmi diumumkan pada hari Senin, Kamis, dan Sabtu pukul 17:45 WIB.",
      results: [
        {
          date: "16/05/2025",
          numbers: ["3", "6", "9", "2"],
          prizes: {
            "1st Prize": "Rp 120.000.000",
            "2nd Prize": "Rp 60.000.000",
            "3rd Prize": "Rp 30.000.000",
            Consolation: "Rp 6.000.000",
          },
        },
        {
          date: "13/05/2025",
          numbers: ["7", "1", "5", "8"],
          prizes: {
            "1st Prize": "Rp 120.000.000",
            "2nd Prize": "Rp 60.000.000",
            "3rd Prize": "Rp 30.000.000",
            Consolation: "Rp 6.000.000",
          },
        },
        {
          date: "11/05/2025",
          numbers: ["2", "9", "0", "4"],
          prizes: {
            "1st Prize": "Rp 120.000.000",
            "2nd Prize": "Rp 60.000.000",
            "3rd Prize": "Rp 30.000.000",
            Consolation: "Rp 6.000.000",
          },
        },
      ],
    },
    {
      name: "Sydney Pools",
      website: "sydneypools.com",
      schedule: "Setiap hari: 14:00 WIB",
      timezone: "GMT+10",
      description:
        "Sydney Pools adalah pasaran togel resmi dari Australia. Hasil keluaran resmi diumumkan setiap hari pukul 14:00 WIB.",
      results: [
        {
          date: "17/05/2025",
          numbers: ["5", "1", "0", "4"],
          prizes: {
            "1st Prize": "Rp 110.000.000",
            "2nd Prize": "Rp 55.000.000",
            "3rd Prize": "Rp 27.500.000",
            Consolation: "Rp 5.500.000",
          },
        },
        {
          date: "16/05/2025",
          numbers: ["9", "2", "7", "6"],
          prizes: {
            "1st Prize": "Rp 110.000.000",
            "2nd Prize": "Rp 55.000.000",
            "3rd Prize": "Rp 27.500.000",
            Consolation: "Rp 5.500.000",
          },
        },
        {
          date: "15/05/2025",
          numbers: ["3", "8", "1", "5"],
          prizes: {
            "1st Prize": "Rp 110.000.000",
            "2nd Prize": "Rp 55.000.000",
            "3rd Prize": "Rp 27.500.000",
            Consolation: "Rp 5.500.000",
          },
        },
      ],
    },
  ])

  return (
    <div>
      <h2 className="text-2xl font-bold text-white mb-6">Pools Resmi</h2>

      <Tabs defaultValue="hongkong-pools" className="w-full">
        <TabsList className="grid w-full grid-cols-3 bg-purple-900/50 mb-6">
          {poolsData.map((pool) => (
            <TabsTrigger
              key={pool.name}
              value={pool.name.toLowerCase().replace(" ", "-")}
              className="data-[state=active]:bg-purple-800"
            >
              {pool.name}
            </TabsTrigger>
          ))}
        </TabsList>

        {poolsData.map((pool) => (
          <TabsContent key={pool.name} value={pool.name.toLowerCase().replace(" ", "-")}>
            <Card className="bg-white/10 backdrop-blur-md border-purple-500/20">
              <CardHeader>
                <div className="flex justify-between items-center">
                  <CardTitle className="text-white">{pool.name}</CardTitle>
                  <Badge className="bg-purple-700 flex items-center gap-1">{pool.schedule}</Badge>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 gap-6">
                  <div className="md:col-span-1">
                    <div className="bg-purple-800/50 rounded-lg p-4 h-full">
                      <h3 className="text-lg font-medium text-white mb-3 flex items-center">
                        <Info className="h-5 w-5 mr-2 text-yellow-400" />
                        Informasi
                      </h3>
                      <div className="grid grid-cols-2 sm:grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <p className="text-purple-200 mb-1">Website Resmi:</p>
                          <a
                            href={`https://${pool.website}`}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-blue-400 hover:text-blue-300 flex items-center"
                          >
                            {pool.website}
                            <ExternalLink className="h-3 w-3 ml-1" />
                          </a>
                        </div>
                        <div>
                          <p className="text-purple-200 mb-1">Jadwal:</p>
                          <p className="text-white">{pool.schedule}</p>
                        </div>
                        <div>
                          <p className="text-purple-200 mb-1">Zona Waktu:</p>
                          <p className="text-white">{pool.timezone}</p>
                        </div>
                        <div>
                          <p className="text-purple-200 mb-1">Deskripsi:</p>
                          <p className="text-white">{pool.description}</p>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="md:col-span-2">
                    <div className="bg-purple-800/50 rounded-lg p-4">
                      <h3 className="text-lg font-medium text-white mb-3">Hasil Keluaran Terbaru</h3>
                      <div className="space-y-4 sm:space-y-6">
                        {pool.results.map((result, idx) => (
                          <div key={idx} className="bg-purple-900/50 rounded-lg p-3 sm:p-4 border border-purple-700/30">
                            <div className="flex justify-between items-center mb-2 sm:mb-3">
                              <h4 className="font-medium text-white">{result.date}</h4>
                            </div>
                            <div className="flex justify-center space-x-2 sm:space-x-4 mb-3 sm:mb-4">
                              {result.numbers.map((number, numIdx) => (
                                <div
                                  key={numIdx}
                                  className="w-10 h-10 sm:w-12 sm:h-12 rounded-full flex items-center justify-center text-lg sm:text-xl font-bold bg-purple-700 text-white border-2 border-yellow-400"
                                >
                                  {number}
                                </div>
                              ))}
                            </div>
                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                              {Object.entries(result.prizes).map(([prize, amount], prizeIdx) => (
                                <div key={prizeIdx} className="flex justify-between">
                                  <span className="text-purple-200">{prize}:</span>
                                  <span className="text-white font-medium">{amount}</span>
                                </div>
                              ))}
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        ))}
      </Tabs>
    </div>
  )
}
