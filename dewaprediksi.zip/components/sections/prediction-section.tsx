"use client"

import { useState } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { CalendarIcon, TrendingUpIcon, TargetIcon, BarChart3Icon } from "lucide-react"

type PredictionData = {
  market: string
  date: string
  angkaMain: string
  angkaJitu: string
  colok: string
  kepala: string
  ekor: string
  lineInvest: string[]
  bbfs: string
  shio: string
}

export function PredictionSection() {
  const [predictions] = useState<PredictionData[]>([
    {
      market: "Hongkong",
      date: "18 Mei 2025",
      angkaMain: "2 7 5 9",
      angkaJitu: "2795",
      colok: "2 & 9",
      kepala: "2 7 5",
      ekor: "7 9 5",
      lineInvest: ["27*95", "57*29", "79*25", "95*27"],
      bbfs: "279538",
      shio: "Kerbau",
    },
    {
      market: "Singapore",
      date: "18 Mei 2025",
      angkaMain: "3 8 1 6",
      angkaJitu: "3816",
      colok: "3 & 6",
      kepala: "3 8 1",
      ekor: "8 1 6",
      lineInvest: ["38*16", "81*36", "16*38", "36*81"],
      bbfs: "381642",
      shio: "Naga",
    },
    {
      market: "Sydney",
      date: "18 Mei 2025",
      angkaMain: "4 0 9 2",
      angkaJitu: "4092",
      colok: "4 & 2",
      kepala: "4 0 9",
      ekor: "0 9 2",
      lineInvest: ["40*92", "09*42", "92*40", "42*09"],
      bbfs: "409275",
      shio: "Monyet",
    },
    {
      market: "Macau",
      date: "18 Mei 2025",
      angkaMain: "6 3 7 1",
      angkaJitu: "6371",
      colok: "6 & 1",
      kepala: "6 3 7",
      ekor: "3 7 1",
      lineInvest: ["63*71", "37*61", "71*63", "61*37"],
      bbfs: "637194",
      shio: "Ayam",
    },
    {
      market: "Taiwan",
      date: "18 Mei 2025",
      angkaMain: "5 2 8 4",
      angkaJitu: "5284",
      colok: "5 & 4",
      kepala: "5 2 8",
      ekor: "2 8 4",
      lineInvest: ["52*84", "28*54", "84*52", "54*28"],
      bbfs: "528461",
      shio: "Kambing",
    },
  ])

  return (
    <div>
      <h2 className="text-2xl font-bold text-white mb-6">Prediksi Togel Jitu</h2>

      <Tabs defaultValue="hongkong" className="w-full">
        <TabsList className="grid w-full grid-cols-5 bg-purple-900/50 mb-6">
          {predictions.map((pred) => (
            <TabsTrigger
              key={pred.market}
              value={pred.market.toLowerCase()}
              className="data-[state=active]:bg-purple-800"
            >
              {pred.market}
            </TabsTrigger>
          ))}
        </TabsList>

        {predictions.map((pred) => (
          <TabsContent key={pred.market} value={pred.market.toLowerCase()}>
            <Card className="bg-white/10 backdrop-blur-md border-purple-500/20">
              <CardHeader>
                <div className="flex justify-between items-center">
                  <CardTitle className="text-white">Prediksi Togel {pred.market}</CardTitle>
                  <Badge className="bg-purple-700 flex items-center gap-1">
                    <CalendarIcon className="h-3 w-3" />
                    {pred.date}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 gap-6">
                  <div className="space-y-6">
                    <div className="bg-purple-800/50 rounded-lg p-4">
                      <h3 className="text-lg font-medium text-white mb-3 flex items-center">
                        <TargetIcon className="h-5 w-5 mr-2 text-yellow-400" />
                        Angka Main
                      </h3>
                      <div className="flex justify-center space-x-2 sm:space-x-3">
                        {pred.angkaMain.split(" ").map((num, idx) => (
                          <div
                            key={idx}
                            className="w-10 h-10 sm:w-12 sm:h-12 rounded-full flex items-center justify-center text-lg sm:text-xl font-bold bg-purple-700 text-white border-2 border-yellow-400"
                          >
                            {num}
                          </div>
                        ))}
                      </div>
                    </div>

                    <div className="bg-purple-800/50 rounded-lg p-4">
                      <h3 className="text-lg font-medium text-white mb-3 flex items-center">
                        <TrendingUpIcon className="h-5 w-5 mr-2 text-yellow-400" />
                        Angka Jitu
                      </h3>
                      <div className="flex justify-center">
                        <div className="text-2xl sm:text-3xl font-bold text-yellow-300 tracking-widest bg-purple-900/70 px-4 sm:px-6 py-2 sm:py-3 rounded-lg border-2 border-yellow-500/50">
                          {pred.angkaJitu}
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="bg-purple-800/50 rounded-lg p-4">
                    <h3 className="text-lg font-medium text-white mb-3 flex items-center">
                      <BarChart3Icon className="h-5 w-5 mr-2 text-yellow-400" />
                      Detail Prediksi
                    </h3>
                    <div className="space-y-3">
                      <div className="flex justify-between">
                        <span className="text-purple-200">Colok Bebas:</span>
                        <span className="text-white font-medium">{pred.colok}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-purple-200">Kepala:</span>
                        <span className="text-white font-medium">{pred.kepala}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-purple-200">Ekor:</span>
                        <span className="text-white font-medium">{pred.ekor}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-purple-200">BBFS:</span>
                        <span className="text-white font-medium">{pred.bbfs}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-purple-200">Shio:</span>
                        <span className="text-white font-medium">{pred.shio}</span>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="mt-6 bg-purple-800/50 rounded-lg p-4">
                  <h3 className="text-lg font-medium text-white mb-3">Line Invest</h3>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                    {pred.lineInvest.map((line, idx) => (
                      <div
                        key={idx}
                        className="bg-purple-900/70 text-center py-2 px-3 rounded-md border border-purple-600/50 text-white font-medium"
                      >
                        {line}
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        ))}
      </Tabs>
    </div>
  )
}
