"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { motion } from "framer-motion"

export function HeroSection() {
  const [currentBg, setCurrentBg] = useState(0)
  const backgrounds = [
    "bg-[url('/abstract-purple-lottery.png')]",
    "bg-[url('/colorful-lottery-balls.png')]",
    "bg-[url('/dark-purple-fortune.png')]",
  ]

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentBg((prev) => (prev + 1) % backgrounds.length)
    }, 5000)
    return () => clearInterval(interval)
  }, [])

  // Tambahkan CSS untuk animasi baru jika belum ada
  useEffect(() => {
    if (!document.getElementById("hero-animations")) {
      const style = document.createElement("style")
      style.id = "hero-animations"
      style.textContent = `
        @keyframes spin-slow {
          from {
            transform: translate(-50%, -50%) rotate(0deg);
          }
          to {
            transform: translate(-50%, -50%) rotate(360deg);
          }
        }
        
        @keyframes spin-slow-reverse {
          from {
            transform: translate(-50%, -50%) rotate(0deg);
          }
          to {
            transform: translate(-50%, -50%) rotate(-360deg);
          }
        }
        
        .animate-spin-slow {
          animation: spin-slow 20s linear infinite;
        }
        
        .animate-spin-slow-reverse {
          animation: spin-slow-reverse 15s linear infinite;
        }
      `
      document.head.appendChild(style)
    }
  }, [])

  return (
    <div className="w-full h-[400px] sm:h-[500px] md:h-[600px] relative overflow-hidden">
      {/* Background Images */}
      {backgrounds.map((bg, index) => (
        <div
          key={index}
          className={`absolute inset-0 transition-opacity duration-1000 ${
            index === currentBg ? "opacity-100" : "opacity-0"
          } ${bg} bg-cover bg-center`}
        ></div>
      ))}

      {/* Overlay */}
      <div className="absolute inset-0 bg-gradient-to-b from-purple-900/70 via-indigo-900/80 to-black/90"></div>

      {/* Content */}
      <div className="relative z-10 h-full flex flex-col items-center justify-center px-4 text-center container mx-auto">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8 }}>
          <h1 className="text-4xl sm:text-5xl md:text-7xl font-bold text-white mb-4 sm:mb-6">
            <span className="bg-clip-text text-transparent bg-gradient-to-r from-yellow-400 via-amber-300 to-yellow-400">
              DEWA
            </span>{" "}
            <span className="bg-clip-text text-transparent bg-gradient-to-r from-purple-400 via-pink-400 to-red-400">
              PREDIKSI
            </span>
          </h1>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
        >
          <p className="text-lg sm:text-xl md:text-2xl text-purple-200 mb-6 sm:mb-10 max-w-3xl">
            Ramalan Angka Sakti dengan Kekuatan Ilahi untuk Semua Pasaran Togel
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          className="flex flex-col sm:flex-row gap-4 sm:gap-6"
        >
          <Button
            size="lg"
            className="bg-gradient-to-r from-yellow-600 to-amber-600 hover:from-yellow-700 hover:to-amber-700 text-white border-none text-base sm:text-lg h-12 sm:h-14 px-6 sm:px-8"
          >
            Dapatkan Ramalan
          </Button>
          <Button
            size="lg"
            variant="outline"
            className="border-yellow-400 text-yellow-200 hover:bg-yellow-800/30 hover:text-white text-base sm:text-lg h-12 sm:h-14 px-6 sm:px-8"
          >
            Lihat Hasil Togel
          </Button>
        </motion.div>

        {/* Animated Balls */}
        <div className="absolute inset-0 pointer-events-none overflow-hidden">
          {typeof window !== "undefined" && <ClientSideBalls />}
        </div>

        {/* Tambahkan elemen dekoratif di sekitar judul */}
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-64 h-64 md:w-96 md:h-96 border-4 border-yellow-500/20 rounded-full animate-spin-slow"></div>
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-80 h-80 md:w-[28rem] md:h-[28rem] border-4 border-purple-500/20 rounded-full animate-spin-slow-reverse"></div>
      </div>

      {/* Wave Divider */}
      <div className="absolute bottom-0 left-0 w-full overflow-hidden">
        <svg
          className="relative block w-full h-[70px]"
          xmlns="http://www.w3.org/2000/svg"
          viewBox="0 0 1200 120"
          preserveAspectRatio="none"
        >
          <path
            d="M0,0V46.29c47.79,22.2,103.59,32.17,158,28,70.36-5.37,136.33-33.31,206.8-37.5C438.64,32.43,512.34,53.67,583,72.05c69.27,18,138.3,24.88,209.4,13.08,36.15-6,69.85-17.84,104.45-29.34C989.49,25,1113-14.29,1200,52.47V0Z"
            fill="#312e81"
            opacity="0.25"
          ></path>
          <path
            d="M0,0V15.81C13,36.92,27.64,56.86,47.69,72.05,99.41,111.27,165,111,224.58,91.58c31.15-10.15,60.09-26.07,89.67-39.8,40.92-19,84.73-46,130.83-49.67,36.26-2.85,70.9,9.42,98.6,31.56,31.77,25.39,62.32,62,103.63,73,40.44,10.79,81.35-6.69,119.13-24.28s75.16-39,116.92-43.05c59.73-5.85,113.28,22.88,168.9,38.84,30.2,8.66,59,6.17,87.09-7.5,22.43-10.89,48-26.93,60.65-49.24V0Z"
            fill="#312e81"
            opacity="0.5"
          ></path>
          <path
            d="M0,0V5.63C149.93,59,314.09,71.32,475.83,42.57c43-7.64,84.23-20.12,127.61-26.46,59-8.63,112.48,12.24,165.56,35.4C827.93,77.22,886,95.24,951.2,90c86.53-7,172.46-45.71,248.8-84.81V0Z"
            fill="#312e81"
          ></path>
        </svg>
      </div>
    </div>
  )
}

function Ball() {
  const [ballProps, setBallProps] = useState({
    size: 0,
    color: "",
    left: 0,
    animationDuration: 0,
    delay: 0,
    visible: false,
  })

  // Only run this effect on the client side
  useEffect(() => {
    // Generate consistent values on client side
    const size = Math.floor(Math.random() * 30) + 10
    const colors = [
      "bg-red-500",
      "bg-blue-500",
      "bg-green-500",
      "bg-yellow-500",
      "bg-purple-500",
      "bg-pink-500",
      "bg-indigo-500",
    ]
    const color = colors[Math.floor(Math.random() * colors.length)]
    const left = Math.random() * 100
    const animationDuration = Math.floor(Math.random() * 20) + 10
    const delay = Math.random() * 5

    setBallProps({
      size,
      color,
      left,
      animationDuration,
      delay,
      visible: true,
    })
  }, [])

  // Don't render anything during SSR or before client-side values are set
  if (!ballProps.visible) return null

  return (
    <motion.div
      className={`absolute rounded-full ${ballProps.color} opacity-30`}
      style={{
        width: ballProps.size,
        height: ballProps.size,
        left: `${ballProps.left}%`,
        top: -100,
      }}
      animate={{
        y: ["0vh", "120vh"],
        x: [`${ballProps.left}vw`, `${ballProps.left + (Math.random() * 20 - 10)}vw`],
      }}
      transition={{
        duration: ballProps.animationDuration,
        repeat: Number.POSITIVE_INFINITY,
        delay: ballProps.delay,
        ease: "linear",
      }}
    />
  )
}

function ClientSideBalls() {
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) return null

  return (
    <>
      {[...Array(15)].map((_, i) => (
        <Ball key={i} />
      ))}
    </>
  )
}
