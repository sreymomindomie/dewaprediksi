/** @type {import('next').NextConfig} */
const nextConfig = {
  env: {
    API_KEY: "key-w0jk8m",
  },
  eslint: {
    ignoreDuringBuilds: true,
  },
  typescript: {
    ignoreBuildErrors: true,
  },
  images: {
    domains: ['api.fenghuochatbot.site'],
    unoptimized: true,
  },
};

export default nextConfig;
