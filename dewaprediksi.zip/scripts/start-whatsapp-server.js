const { spawn } = require("child_process")
const path = require("path")

// Path to the WhatsApp server script
const whatsappServerPath = path.join(__dirname, "whatsapp-server.js")

// Start the WhatsApp server
console.log("Starting WhatsApp verification server...")
const whatsappServer = spawn("node", [whatsappServerPath], {
  stdio: "inherit",
})

whatsappServer.on("close", (code) => {
  console.log(`WhatsApp server exited with code ${code}`)
})

// Handle process termination
process.on("SIGINT", () => {
  whatsappServer.kill("SIGINT")
  process.exit()
})

process.on("SIGTERM", () => {
  whatsappServer.kill("SIGTERM")
  process.exit()
})
