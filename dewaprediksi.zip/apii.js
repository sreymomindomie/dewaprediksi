const express = require("express")
const wppconnect = require("@wppconnect-team/wppconnect")
const path = require("path")
const fs = require("fs")

const app = express()
const PORT = 8000
const sessionPath = path.join(__dirname, "session")
fs.mkdirSync(sessionPath, { recursive: true })

// Store client reference
let client = null

// API endpoint to check WhatsApp number
app.get("/check", async (req, res) => {
  const nomor = req.query.nomor
  if (!nomor) {
    return res.status(400).json({
      error: "Nomor tidak disediakan. Gunakan format: /check?nomor=6281234567890",
    })
  }
  console.log(`[ SPAM CHECK - ${nomor} ]`)

  if (!client) {
    return res.status(503).json({
      error: "WhatsApp client not connected. Please scan the QR code first.",
    })
  }

  try {
    if (!/^\d+$/.test(nomor) || !nomor.startsWith("62")) {
      return res.status(400).json({
        error: "Format nomor tidak valid. Gunakan format internasional (contoh: 628xxxxxx).",
      })
    }
    const status = await client.checkNumberStatus(nomor).catch(() => null)
    if (status && status.id) {
      if (status.canReceiveMessage) {
        console.log(`[ STATUS : ACTIVE, Nomor: ${nomor} ]`)
        return res.json({
          wa: "active",
          nomor: nomor,
        })
      } else {
        console.log(`[ STATUS : INACTIVE, Nomor: ${nomor} ]`)
        return res.json({
          wa: "inactive",
          nomor: nomor,
        })
      }
    } else {
      console.log(`[ STATUS : ERROR, Nomor: ${nomor} - Invalid Response ]`)
      return res.status(400).json({
        error: `Nomor ${nomor} tidak valid atau tidak dapat diproses.`,
      })
    }
  } catch (error) {
    console.error(`[ STATUS : ERROR, Nomor: ${nomor} ]`, error)
    return res.status(500).json({
      error: `Terjadi kesalahan saat memproses nomor ${nomor}.`,
    })
  }
})

// Initialize WhatsApp client
function initWhatsApp() {
  console.log("[ INITIALIZING ] Starting WhatsApp client...")

  wppconnect
    .create({
      session: "wa-spam-checker",
      folderNameToken: "session",
      sessionToken: `${sessionPath}/`,
      logLevel: "error",
      headless: true, // Set to true for headless mode on VPS
      qrTimeout: 0,
      puppeteerOptions: {
        args: [
          "--no-sandbox",
          "--disable-setuid-sandbox",
          "--disable-dev-shm-usage",
          "--disable-accelerated-2d-canvas",
          "--no-first-run",
          "--no-zygote",
          "--single-process",
          "--disable-gpu",
        ],
      },
      catchQR: (base64Qr, asciiQR) => {
        // Display ASCII QR code in terminal
        console.log("=".repeat(50))
        console.log("[ QRCODE ] SCAN THIS QR CODE WITH YOUR WHATSAPP:")
        console.log("=".repeat(50))
        console.log(asciiQR)
        console.log("=".repeat(50))
        console.log("[ INFO ] If the QR code is not visible properly in your terminal,")
        console.log("[ INFO ] you can also access the API at http://YOUR_SERVER_IP:3000/qrcode")
      },
    })
    .then((c) => {
      client = c
      console.log("[ QRCODE ] Silakan scan QR Code di terminal.")

      client.onStateChange((state) => {
        console.log(`[ STATE CHANGE ] ${state}`)
        if (state === "CONNECTED") {
          console.log("=".repeat(50))
          console.log(`[ SUCCESSFULLY LOGIN AT YOUR ACCOUNT ]`)
          console.log("=".repeat(50))
        }
      })
    })
    .catch((err) => console.error("Error initializing WhatsApp client:", err))
}

// Also provide a web endpoint to get the QR code as base64 for remote access if needed
app.get("/qrcode", async (req, res) => {
  if (!client) {
    return res.status(503).json({ error: "Client not initialized" })
  }

  try {
    // Get the QR code from the client
    const qrCode = await client.getQrCode()
    if (qrCode) {
      res.json({ qrcode: qrCode })
    } else {
      res.status(404).json({ error: "QR code not available or already scanned" })
    }
  } catch (error) {
    console.error("Error getting QR code:", error)
    res.status(500).json({ error: "Failed to get QR code" })
  }
})

// Start the server and initialize WhatsApp
app.listen(PORT, () => {
  console.log(`[ SERVER ] API running at http://localhost:${PORT}`)
  console.log(`[ SERVER ] Use /check?nomor=628xxxxxx to check numbers`)
  initWhatsApp()
})
